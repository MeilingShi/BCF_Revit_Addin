﻿using BCF_Revit_Addin.Data;
using BCF_Revit_Addin.BCF;
using BCF_Revit_Addin.BCF.BCF2._1;

using BCF_Revit_Addin.GUI;
using System;
using System.Collections.Generic;

using System.Drawing;

using System.Linq;

using BCF_Revit_Addin.Data_Logic;

using System.Windows.Forms;
using Autodesk.Revit.UI;


namespace BCF_Revit_Addin
{
    public partial class BcfRevitStartForm : System.Windows.Forms.Form
    {
        private UIApplication uiapp;
        private ConvertToViewHandler Handler;
        private ExternalEvent ExtEvent;
        private BCFFileManager fileManager = new BCFFileManager();
        BcfFile bcffile = new BcfFile();
        Markup markup = new Markup();

        public BcfRevitStartForm( UIApplication _uiapp, ExternalEvent exEvent, ConvertToViewHandler handler )
        {
            
            InitializeComponent();
            try
            {
                ExtEvent = exEvent;
                Handler = handler;
                uiapp = _uiapp;
            }
            catch(Exception ex1)
            {
                TaskDialog.Show("Error!", "exception: " + ex1);
            }
        }


        private void BcfRevitStart_Load(object sender, EventArgs e)
        {

        }

        private void btn_laden_Click(object sender, EventArgs e)
        {
            //var fileManager = new BCFFileManager();
            fileManager.bcfFileLoad(lb_bcfFileLoad);
            
        }

        private void btn_newTopic_Click(object sender, EventArgs e)
        {
            ClearFormFelder();
            pnl_bcfViewer.Visible = true;
            btn_createBcf.Visible = true;
            btn_save.Visible = false;
            


        }

        private void btn_createBcf_Click(object sender, EventArgs e)
        {// create bcf as a method writen later 

            try {
                string tempPath = "C:\\Users\\solconpro\\Desktop\\Meiling Shi\\BCF Issues\\";
                //BcfFile bcfFile = new BcfFile();    
                //Markup markup = new Markup();
                markup.Topic = new Topic();
                
                markup.Topic.Title = string.IsNullOrEmpty(tb_title.Text) ? "Defalt": tb_title.Text;
                markup.Topic.Description = string.IsNullOrEmpty(rtb_description.Text) ? "Default": rtb_description.Text;
                markup.Topic.TopicType = string.IsNullOrEmpty(cb_typ.SelectedItem.ToString()) ? "Default" : "Hallo";
                    //cb_typ.SelectedItem.ToString();
                markup.Topic.AssignedTo = string.IsNullOrEmpty(cb_assignto.SelectedItem.ToString()) ? "Defalt": cb_assignto.SelectedItem.ToString();
                markup.Topic.TopicStatus = string.IsNullOrEmpty(cb_status.SelectedItem.ToString()) ? "Default": cb_status.SelectedItem.ToString();
                markup.Topic.Priority = string.IsNullOrEmpty(cb_priority.SelectedItem.ToString()) ? "Default": cb_priority.SelectedItem.ToString();
                markup.Topic.Labels = (clb_label.CheckedItems.Cast<string>().ToList().Count == 0) ? new List<string>() : clb_label.CheckedItems.Cast<string>().ToList();
                //? : clb_label.CheckedItems.Cast<string>().ToList());


                pcb_screenshot.Image =  ScreenshotUtils.GetRevitSnapshot(uiapp.ActiveUIDocument);

                var viewp = new ViewPoint();
                viewp.VisInfo = new VisualizationInfo();
                viewp.VisInfo = ScreenshotUtils.GenerateViewpoint(uiapp.ActiveUIDocument);

                markup.Viewpoints = new System.Collections.ObjectModel.ObservableCollection<ViewPoint>();
                markup.Viewpoints.Add(viewp);
                bcffile.Issues = new System.Collections.ObjectModel.ObservableCollection<Markup>();
                bcffile.Issues.Add(markup);

                bool resul = BCFFileManager.SaveBcfFile(bcffile);


                //int screenWidth = Screen.GetBounds(new System.Drawing.Point(0, 0)).Width;
                //int screenHeight = Screen.GetBounds(new System.Drawing.Point(0, 0)).Height;
                //Bitmap bmpScreenShot = new Bitmap(screenWidth, screenHeight);
                //Graphics gfx = Graphics.FromImage((Image)bmpScreenShot);
                //gfx.CopyFromScreen(0, 0, 0, 0, new System.Drawing.Size(screenWidth, screenHeight));
                //pcb_screenshot.Image = bmpScreenShot;
                //bmpScreenShot.Save("test.jpg", ImageFormat.Jpeg);
                // how to find it later then? and store it into Snapshot path
                                                                  // hier 


            }
            catch(Exception ex)
            {
                TaskDialog.Show("Exception", ex.ToString());
            }

            btn_createBcf.Visible = false;
        }


        private void lb_bcfFileLoad_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnl_bcfViewer.Visible = true;
            
            string clFilename = ((FullFilename)lb_bcfFileLoad.SelectedItem).FileFullname;
             bcffile = fileManager.OpenBcfFile(clFilename);
             markup = bcffile.SelectedIssue;
            tb_title.Text = markup.Topic.Title;
            rtb_description.Text = markup.Topic.Description;
            cb_assignto.Text = markup.Topic.TopicType;
            cb_status.Text = markup.Topic.TopicStatus;
            cb_priority.Text = markup.Topic.Priority;

            if (markup.Topic.Labels != null)
            {
                foreach(var label in markup.Topic.Labels)
                {
                    clb_label.Items.Add(label);
                }
                
            }

            dgv_comments.DataSource = GuiLogic.ConvertListToDataTable(markup.Comment);
            // hier only the first Snapshot will be displayed--------------------------------------- 
            try
            {
                pcb_screenshot.Image = Image.FromFile(markup.Viewpoints.First().SnapshotPath);
            }
            catch
            {
                pcb_screenshot.Hide();
            }


            // zoom to viewpoint-------------------------------------------------------------------
            try
            {
                Handler.v = markup.Viewpoints.First().VisInfo;
                // Handler.Execute(uiapp);
                ExtEvent.Raise();

            }
            catch (Exception ex)
            {
                TaskDialog.Show("Error!", "Exception: " + ex);
            }

        }

        //private void OnOpenView(object sender, EventArgs e, Markup markup)
        //{
        //    try
        //    {
        //        //if (Bcfier.SelectedBcf() == null)
        //        //    return;
        //        //var view = e.Parameter as ViewPoint;
        //        //if (view == null)
        //        //    return;
        //        UIDocument uidoc = uiapp.ActiveUIDocument;

        //        if (uidoc.ActiveView.ViewType == ViewType.ThreeD)
        //        {
        //            var view3D = (View3D)uidoc.ActiveView;
        //            if (view3D.IsPerspective)
        //            {
        //                System.Windows.MessageBox.Show("This operation is not allowed in a Perspective View.\nPlease close the current window(s) and retry.",
        //                    "Warning!", MessageBoxButton.OK, MessageBoxImage.Warning);
        //                return;
        //            }

        //        }
        //        Handler.v = markup.Viewpoints.First().VisInfo;
        //        ExtEvent.Raise();
        //    }
        //    catch (System.Exception ex1)
        //    {
        //        TaskDialog.Show("Error opening a View!", "exception: " + ex1);
        //    }
        //}

        private void tb_title_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgv_comments_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        /// <summary>
        /// Form closed event handler
        /// </summary>
        /// <param name="e"></param>
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            // the form own both the event and the handler
            // we should dispose it before we are closed
            ExtEvent.Dispose();
            ExtEvent = null;
            Handler = null;

            // do not forget to call the base class
            base.OnFormClosed(e);
        }

       


        // clear all the inputsfelder
        private void ClearFormFelder()
        {
            tb_title.Text = null;
            tb_title.Clear();

            rtb_description.Text = null;
            rtb_description.Clear();

       
            //cb_assignto.Items.Clear();
            //cb_status.Items.Clear();
            //cb_priority.Items.Clear();
            //clb_label.Items.Clear();
            dgv_comments.DataSource = null;
            dgv_comments.Rows.Clear();
            rtb_comments.Clear();
            pcb_screenshot.Image = null;
            pcb_screenshot.Invalidate();

        }

        private void btn_setting_Click(object sender, EventArgs e)
        {
            Setting setForm = new Setting();
            setForm.ShowDialog();

        }

        private void cb_typ_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

     
    }
}
