﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using BCF_Revit_Addin.BCF.BCF2._1;

namespace BCF_Revit_Addin.GUI
{
    public static class GuiLogic
    {
        public static DataTable ConvertListToDataTable(Comment[] list)
        {
            DataTable table = new DataTable();
            table.Columns.Add("Time");
            table.Columns.Add("Autor");
            table.Columns.Add("Commentar");
            
            foreach (var comment in list)
            {
                DataRow row = table.NewRow();
                row["Time"] = comment.Date;
                row["Autor"] = comment.Author;
                row["Commentar"] = comment.Comment1;
                table.Rows.Add(row);
            }
            return table;
        }






    }
}
