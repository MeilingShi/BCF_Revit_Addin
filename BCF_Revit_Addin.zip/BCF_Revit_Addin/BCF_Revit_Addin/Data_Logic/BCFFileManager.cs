﻿using BCF_Revit_Addin.BCF;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Xml.Serialization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;

namespace BCF_Revit_Addin.Data
{
    public class BCFFileManager
    {
        public void bcfFileLoad (ListBox lb_bcfFileLoad)
        {
            Stream bcfFileStream = null;
            OpenFileDialog bcfPfadDialog = new OpenFileDialog();

            bcfPfadDialog.InitialDirectory = "c:\\";
            bcfPfadDialog.Filter = "BCF File (*.bcfzip)|*.bcfzip|All files (*.*)|*.*";
            bcfPfadDialog.FilterIndex = 2;
            bcfPfadDialog.RestoreDirectory = true;
            bcfPfadDialog.Multiselect = true;

            if (bcfPfadDialog.ShowDialog() == DialogResult.OK)
            {
                List<String> fullFileName = new List<string>(bcfPfadDialog.FileNames);

                foreach (string filename in fullFileName)
                {
                    lb_bcfFileLoad.Items.Add(filename.Substring(filename.LastIndexOf(@"\") + 1));
                }
                try
                {
                    if ((bcfFileStream = bcfPfadDialog.OpenFile()) != null)
                    {

                        using (bcfFileStream)
                        {
                            // Insert code to read the stream here.

                        }

                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);

                }
            }
        }

        // have to be static?
        /// <summary>
        /// Logic that extracts files from a bcfzip and deserializes them
        /// </summary>
        /// <param name="bcfzipfile">Path to the .bcfzip file</param>
        /// <returns></returns>
        private BcfFile OpenBcfFile(string bcfzipfile)  
        {
            var bcffile = new BcfFile();
            try
            {
                if (!File.Exists(bcfzipfile) || !String.Equals(Path.GetExtension(bcfzipfile),
                    ".bcfzip", StringComparison.InvariantCultureIgnoreCase))
                    return bcffile;
                bcffile.Filename = Path.GetFileNameWithoutExtension(bcfzipfile);
                bcffile.Fullname = bcfzipfile;  //Path to the .bcfzip file


                using(ZipArchive archive = ZipFile.OpenRead(bcfzipfile))
                {
                    archive.ExtractToDirectory(bcffile.TempPath);
                    // Key method, extracts all the file in zip into a dictionary and store it in bcffile.Temppath
                    // destinationDirectoryName:The path to the directory to place the extracted files in.
                }


                // Get Info from project.bcfp
                var projectFile = Path.Combine(bcffile.TempPath, "project.bcfp");
                if (File.Exists(projectFile))
                {
                    var project = DeserializeProject(projectFile);
                    var g = Guid.NewGuid();
                    Guid.TryParse(project.Project.ProjectId, out g);
                    bcffile.ProjectId = g;
                }

                var dir = new DirectoryInfo(bcffile.TempPath); // Filepath until *.bcfzip 

                // ADD ISSUES FOR EACH SUPERFOLDER
                foreach (var folder in dir.GetDirectories())
                {
                    // An issue needs at least the markup file
                    var markupFile = Path.Combine(folder.FullName, "markup.bcf");
                    if (!File.Exists(markupFile))
                        continue;
                    var bcfissue = DeserializeMarkup(markupFile);

                    if (bcfissue == null)
                        continue;


                    // Viewpoints
                    // if it is BCf V2.0, it will have multiple viewpoints
                    if(bcfissue.Viewpoints != null && bcfissue.Viewpoints.Any())
                    {
                        foreach (var viewpoint in bcfissue.Viewpoints)
                        {
                            string viewpointpath = Path.Combine(folder.FullName, viewpoint.Viewpoint);
                            if (File.Exists(viewpointpath))
                            {

                            }
                        }

                    }
                }
            }
            catch(System.Exception ex1)
            {
                System.Windows.MessageBox.Show("exception: " + ex1);
            }


            return bcffile;
        }

        private static ProjectExtension DeserializeProject(string path)
        {
            ProjectExtension output = null;
            try
            {
                using (var projectFile = new FileStream(path, FileMode.Open))
                {
                    var serialzerP = new XmlSerializer(typeof(ProjectExtension));
                    output = serialzerP.Deserialize(projectFile) as ProjectExtension;
                }
            }
            catch(System.Exception ex1)
            {
                System.Windows.MessageBox.Show("exception" + ex1);
            }
            return output;
        }

        private static Markup DeserializeMarkup( string path)
        {
            Markup output = null;
            try
            {
                using(var markupFile = new FileStream(path, FileMode.Open))
                {
                    var serializerM = new XmlSerializer(typeof(Markup));
                    output = serializerM.Deserialize(markupFile) as Markup;
                }
                  
            }
            catch (System.Exception ex1 )
            {
                System.Windows.MessageBox.Show("exception" + ex1);
            }
            return output;
        }

        private static VisualizationInfo DeserializeviewPoint (string path)
        {
            VisualizationInfo output = null;
            try
            {
                using (var viewpointFile = new FileStream(path, FileMode.Open))
                {
                    var serializerV = new XmlSerializer(typeof(VisualizationInfo));
                    output = serializerV.Deserialize(viewpointFile) as VisualizationInfo;
                }
            }
            catch ( System.Exception ex1)
            {
                System.Windows.MessageBox.Show("exception:" + ex1);
            }
            return output;
        }
    }
}
