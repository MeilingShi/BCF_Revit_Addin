﻿using BCF_Revit_Addin.BCF.BCF2._1;
using BCF_Revit_Addin.BCF;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Xml.Serialization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing.Imaging;

namespace BCF_Revit_Addin.Data
{
    public class BCFFileManager : INotifyPropertyChanged
    {
        

        public string bcfFileLoad (ListBox lb_bcfFileLoad)
        {
            string path = "";
            //Stream bcfFileStream = null;
            OpenFileDialog bcfPfadDialog = new OpenFileDialog();

            bcfPfadDialog.InitialDirectory = "c:\\";
            bcfPfadDialog.Filter = "BCF File (*.bcfzip)|*.bcfzip|All files (*.*)|*.*";
            bcfPfadDialog.FilterIndex = 2;
            bcfPfadDialog.RestoreDirectory = true;
            bcfPfadDialog.Multiselect = true;

            if (bcfPfadDialog.ShowDialog() == DialogResult.OK)
            {
                List<String> strFullFilename = new List<string>(bcfPfadDialog.FileNames);
            
                foreach (string f in strFullFilename)
                {
                    if (lb_bcfFileLoad.Items != null)
                    {
                        foreach (var f2 in lb_bcfFileLoad.Items)
                        {
                            if(f2.ToString() != f)
                            {
                                FullFilename clFilename = new FullFilename();
                                clFilename.FileFullname = f;
                                lb_bcfFileLoad.Items.Add(clFilename);
                            }

                        }
                    }
                    else
                    {
                        FullFilename clFilename = new FullFilename();
                        clFilename.FileFullname = f;
                        lb_bcfFileLoad.Items.Add(clFilename);

                    }
                    //FullFilename clFilename = new FullFilename();
                    //clFilename.FileFullname = f;
                    //lb_bcfFileLoad.Items.Add(clFilename);
                   
                    path = Path.GetDirectoryName(f);
                    // path wird überschrieben
                }   
            }
            return path;
        }

        
        /// <summary>
        /// Logic that extracts files from a bcfzip and deserializes them
        /// </summary>
        /// <param name="_path">Path to the .bcfzip file</param>
        /// <returns></returns>
        public BcfFile OpenBcfFile(string _path)  
        {
            var bcffile = new BcfFile();
            try
            {
                if (!File.Exists(_path) || !String.Equals(Path.GetExtension(_path),
                    ".bcfzip", StringComparison.InvariantCultureIgnoreCase))
                    return bcffile;
                bcffile.Filename = Path.GetFileNameWithoutExtension(_path);
                bcffile.Fullname = _path;  //Path to the .bcfzip file


                using(ZipArchive archive = ZipFile.OpenRead(_path))
                {
                    archive.ExtractToDirectory(bcffile.TempPath);
                    // Key method, extracts all the file in zip into a dictionary and store it in bcffile.Temppath
                    // destinationDirectoryName:The path to the directory to place the extracted files in.
                    archive.Dispose();
                }

                
                // Get Info from project.bcfp
                var projectFile = Path.Combine(bcffile.TempPath, "project.bcfp");
                if (File.Exists(projectFile))
                {
                    var project = DeserializeProject(projectFile);
                    var g = Guid.NewGuid();
                    Guid.TryParse(project.Project.ProjectId, out g);
                    bcffile.ProjectId = g;
                }

                var dir = new DirectoryInfo(bcffile.TempPath); // Filepath until *.bcfzip 

                // ADD ISSUES FOR EACH SUPERFOLDER
                foreach (var folder in dir.GetDirectories())
                {
                    // An issue needs at least the markup file
                    var markupFile = Path.Combine(folder.FullName, "markup.bcf");
                    if (!File.Exists(markupFile))
                        continue;
                    //var bcfmarkup = DeserializeMarkup(markupFile);
                    bcffile.SelectedIssue = DeserializeMarkup(markupFile);
                    if (bcffile.SelectedIssue == null)
                        continue;


                    // Viewpoints
                    // if it is BCf V2.0, it will have multiple viewpoints with one file naming viewpoint.bcfv
                    if(bcffile.SelectedIssue.Viewpoints != null && bcffile.SelectedIssue.Viewpoints.Any())
                    {
                        foreach (var viewpoint in bcffile.SelectedIssue.Viewpoints)
                        {
                            string viewpointpath = Path.Combine(folder.FullName, viewpoint.Viewpoint);
                            // viewpoint.Viewpoint store the name of real Viewpoint File name(.bcfv)
                            if (File.Exists(viewpointpath))
                            {
                                viewpoint.VisInfo = DeserializeViewPoint(viewpointpath);
                                viewpoint.SnapshotPath = Path.Combine(folder.FullName, viewpoint.Snapshot);
                            }
                        }
                    }



                    //Is a BCF 1 file, only one viewpoint
                    //there is no Viewpoints tag in the markup
                    //update it to BCF 2
                    else
                    {
                        bcffile.SelectedIssue.Viewpoints = new ObservableCollection<ViewPoint>();
                        string viewpointFile = Path.Combine(folder.FullName, "viewpoint.bcfv");
                        if (File.Exists(viewpointFile))
                        {
                            bcffile.SelectedIssue.Viewpoints.Add(new ViewPoint(true)
                            {
                                VisInfo = DeserializeViewPoint(viewpointFile),
                                SnapshotPath = Path.Combine(folder.FullName, "snapshot.png")
                            });
                            foreach(var comment in bcffile.SelectedIssue.Comment)
                            {
                                comment.Viewpoint = new CommentViewpoint();
                                comment.Viewpoint.Guid = bcffile.SelectedIssue.Viewpoints.First().Guid;
                            }
                        }
                    }
                    
                }
            }

            catch(System.Exception ex1)
            {
                System.Windows.MessageBox.Show("exception: " + ex1);
            }
            
            return bcffile; //wether the bcffile have all importent information? 
        }


       public static bool SaveMarkup (string issuePath, Markup m, string fullname)
        {
            var serializerM = new XmlSerializer(typeof(Markup));
            Stream writerM = new FileStream(issuePath, FileMode.Create);
            serializerM.Serialize(writerM, m);
            writerM.Close();

            using (ZipArchive archive = ZipFile.Open(fullname, ZipArchiveMode.Update))
            {
                string pa = Path.Combine(m.Topic.Guid, "markup.bcf");

                ZipArchiveEntry entry = archive.GetEntry(pa.Replace("\\", "/"));
                entry.Delete();

                archive.CreateEntryFromFile(issuePath, pa.Replace("\\", "/"));

            }
            return true;
        }

        public static bool CreateBcfFile(BcfFile bcffile, System.Drawing.Bitmap snapshot)
        {
            try
            {
                if (bcffile.Issues.Count == 0)
                {
                    System.Windows.MessageBox.Show("The current BCF Report is empty.", "No Issue", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
                if (!Directory.Exists(bcffile.TempPath))
                    Directory.CreateDirectory(bcffile.TempPath);
                // Show save file dialog box
                string name = !string.IsNullOrEmpty(bcffile.Filename) ? bcffile.Filename : "New BCF File";
                string filename = SaveBcfDialog(name);

                // Process save file dialog box results
                if (string.IsNullOrWhiteSpace(filename))
                    return false;
                var bcfProject = new ProjectExtension
                {
                    Project = new Project
                    {
                        Name = string.IsNullOrEmpty(bcffile.ProjectName) ? bcffile.Filename : bcffile.ProjectName,
                        ProjectId = bcffile.ProjectId.Equals(Guid.Empty) ?
                        Guid.NewGuid().ToString() : bcffile.ProjectId.ToString()

                    },
                    ExtensionSchema = ""
                };

                var bcfVersion = new BCF.BCF2._1.Version { VersionId = "2.0", DetailedVersion = "2.0" };

                // Serialization: serializer--> stream --> serialization(stream, object)
                var serializerP = new XmlSerializer(typeof(ProjectExtension));
                Stream writerP = new FileStream(Path.Combine(bcffile.TempPath, "project.bcfp"), FileMode.Create);
                serializerP.Serialize(writerP, bcfProject);
                writerP.Close();

                var serializerVers = new XmlSerializer(typeof(BCF.BCF2._1.Version));
                Stream writerVers = new FileStream(Path.Combine(bcffile.TempPath, "bcf.version"), FileMode.Create);
                serializerVers.Serialize(writerVers, bcfVersion);
                writerVers.Close();

                var serializerV = new XmlSerializer(typeof(VisualizationInfo));
                var serializerM = new XmlSerializer(typeof(Markup));

                foreach (var issue in bcffile.Issues)
                {
                    string issuePath = Path.Combine(bcffile.TempPath, issue.Topic.Guid);
                    if (!Directory.Exists(issuePath))
                        Directory.CreateDirectory(issuePath);

                    if (issue.Viewpoints.Any() && (issue.Viewpoints.Count == 1 || issue.Viewpoints.All(o => o.Viewpoint != "viewpoint.bcfv")))
                    {
                        if (File.Exists(Path.Combine(issuePath, issue.Viewpoints[0].Viewpoint)))
                            File.Delete(Path.Combine(issuePath, issue.Viewpoints[0].Viewpoint));
                        issue.Viewpoints[0].Viewpoint = "viewpoint.bcfv";

                        //if (File.Exists(Path.Combine(issuePath, issue.Viewpoints[0].Snapshot)))
                        //    File.Move(Path.Combine(issuePath, issue.Viewpoints[0].Snapshot), Path.Combine(issuePath, "snapshot.png"));
                        //issue.Viewpoints[0].Snapshot = "snapshot.png";
                    }

                    // serialize markup with updated content
                    Stream writerM = new FileStream(Path.Combine(issuePath, "markup.bcf"), FileMode.Create);
                    serializerM.Serialize(writerM, issue);
                    writerM.Close();

                    // serialize views
                    foreach(var bcfViewpoint in issue.Viewpoints)
                    {
                        Stream writerV = new FileStream(Path.Combine(issuePath, bcfViewpoint.Viewpoint), FileMode.Create);
                        serializerV.Serialize(writerV, bcfViewpoint.VisInfo);
                        writerV.Close();
                    }
                    
                    // save snapshot
                    Stream writerS = new FileStream(Path.Combine(issuePath, "snapshot.png"),FileMode.Create);
                    snapshot.Save(writerS, ImageFormat.Png);                    
                    writerS.Close();

                }
                //overwrite, without doubts
                if (File.Exists(filename))
                    File.Delete(filename);

                ZipFile.CreateFromDirectory(bcffile.TempPath, filename, CompressionLevel.Optimal, false, new ZipEncoder());
          

            }
            catch(Exception ex)
            {
                System.Windows.MessageBox.Show("Exception: " + ex);
            }

            return true;
        }

      

        /// <summary>
        /// Prompts a the user to select where to save the bcfzip
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public static string SaveBcfDialog(string filename)
        {
            var saveFileDialog = new Microsoft.Win32.SaveFileDialog
            {
                Title = "Save as BCF report file (.bcfzip)",
                FileName = filename,
                DefaultExt = ".bcfzip",
                Filter = "BIM Collaboration Format (*.bcfzip)|*.bcfzip"
            };

            //if it goes fine, returns the filename, otherwise empty
            var result = saveFileDialog.ShowDialog();
            return result == true ? saveFileDialog.FileName : "";
        }

        private static ProjectExtension DeserializeProject(string path)
        {
            ProjectExtension output = null;
            try
            {
                using (var projectFile = new FileStream(path, FileMode.Open))
                {
                    var serialzerP = new XmlSerializer(typeof(ProjectExtension));
                    output = serialzerP.Deserialize(projectFile) as ProjectExtension;
                    projectFile.Close();
                }
            }
            catch(System.Exception ex1)
            {
                System.Windows.MessageBox.Show("exception" + ex1);
            }
            return output;
        }

        private static Markup DeserializeMarkup( string path)
        {
            Markup output = null;
            try
            {
                using(var markupFile = new FileStream(path, FileMode.Open))
                {
                    var serializerM = new XmlSerializer(typeof(Markup));
                    output = serializerM.Deserialize(markupFile) as Markup;
                    markupFile.Close();
                }                  
            }
            catch (System.Exception ex1 )
            {
                System.Windows.MessageBox.Show("exception" + ex1);
            }
            return output;
        }

        private static VisualizationInfo DeserializeViewPoint (string path)
        {
            VisualizationInfo output = null;
            try
            {
                using (var viewpointFile = new FileStream(path, FileMode.Open))
                {
                    var serializerV = new XmlSerializer(typeof(VisualizationInfo));
                    output = serializerV.Deserialize(viewpointFile) as VisualizationInfo;
                    viewpointFile.Close();
                }
            }
            catch ( System.Exception ex1)
            {
                System.Windows.MessageBox.Show("exception:" + ex1);
            }
            return output;
        }




        [field: NonSerialized]
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String info)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(info));
            }
        }

    }

    public class FullFilename
    {
        public string FileFullname { get; set; }
        public override string ToString()
        {
            return Path.GetFileName(FileFullname);
        }
    }


    class ZipEncoder : UTF8Encoding
    {
        public ZipEncoder()
        {

        }
        public override byte[] GetBytes(string s)
        {
            s = s.Replace("\\", "/");
            return base.GetBytes(s);
        }
    }

}
