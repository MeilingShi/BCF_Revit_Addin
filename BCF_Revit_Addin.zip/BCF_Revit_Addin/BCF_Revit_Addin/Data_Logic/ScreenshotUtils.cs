﻿using Autodesk.Revit.UI;
using Autodesk.Revit.DB;
using BCF_Revit_Addin.BCF.BCF2._1;
using Point = BCF_Revit_Addin.BCF.BCF2._1.Point;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Drawing;
using BCF_Revit_Addin.Data_Logic;

namespace BCF_Revit_Addin.Data
{
    public static class ScreenshotUtils
    {

        //<summary>
        //Generate a VisualizationInfo of the current view
        //</summary>
        //<returns></returns>
        // http://thebuildingcoder.typepad.com/blog/2012/06/uiview-and-windows-device-coordinates.html
        public static VisualizationInfo GenerateViewpoint( UIDocument uidoc)
        {
            var v = new VisualizationInfo();
            try
            {
                var doc=uidoc.Document;
                

                // Corners of the active UI View, in Revit model coordinates               
                XYZ topLeft = uidoc.GetOpenUIViews()[0].GetZoomCorners()[0];
                XYZ bottomRight = uidoc.GetOpenUIViews()[0].GetZoomCorners()[1];

                //It's a 2D View, not supported by BCF, but will be stored under a custom fields
                // using 2D coordinates and sheet id
                if (uidoc.ActiveView.ViewType != ViewType.ThreeD)
                {
                    v.SheetCamera = new SheetCamera
                    {
                        SheetID = uidoc.ActiveView.Id.IntegerValue,
                        TopLeft = new Point{ X = topLeft.X, Y= topLeft.Y, Z= topLeft.Z},
                        BottomRight = new Point { X = bottomRight.X, Y = bottomRight.Y, Z= bottomRight.Z}
                        
                    };
                }
                else
                {
                    XYZ viewCenter = new XYZ();
                    View3D view3D = (View3D)uidoc.ActiveView;
                    double zoomValue = 1;
                    //assuming hier is only orthogonal view
                    XYZ coordiDif = bottomRight - topLeft;
                    XYZ center = topLeft + 0.5 * coordiDif;

                    // vector going from BR to TL
                    XYZ diagVector = coordiDif;
                    // length of the vector 
                    double dist = topLeft.DistanceTo(bottomRight) / 2;

                    //ViewToWorldScale value ?
                    // https://knowledge.autodesk.com/de/search-result/caas/CloudHelp/cloudhelp/2017/DEU/Revit-API/files/GUID-A7FA8DBC-830E-482D-9B66-147399524442-htm.html
                    zoomValue = dist * Math.Sin(diagVector.AngleTo(view3D.RightDirection)).ToMeters();

                    ViewOrientation3D t = RevitUtils.ConvertBasePoint(doc, viewCenter, uidoc.ActiveView.ViewDirection,
                       uidoc.ActiveView.UpDirection, false);
                    //The viewer's world coordinates are retrieved using the ViewOrientation3D.EyePosition property 
                    //(retrieved from View3D.GetOrientation()). Therefore, in 3D views, View.Origin is always equal 
                    //to the corresponding ViewOrientation3D.EyePosition.
                    XYZ c = t.EyePosition;
                    XYZ vi = t.ForwardDirection;
                    XYZ up = t.UpDirection;

                    v.OrthogonalCamera = new OrthogonalCamera
                    {
                        CameraViewPoint = new Point
                        {
                            X = c.X.ToMeters(),
                            Y = c.Y.ToMeters(),
                            Z = c.Z.ToMeters()
                        },

                        CameraUpVector = new Direction
                        {
                            X = up.X.ToMeters(),
                            Y = up.Y.ToMeters(),
                            Z = up.Z.ToMeters()
                        },

                        CameraDirection = new Direction
                        {
                            X = vi.X.ToMeters() * -1,
                            Y = vi.Y.ToMeters() * -1,
                            Z = vi.Z.ToMeters() * -1
                        },

                        ViewToWorldScale = zoomValue
                    };
                }

                // Components part
                string versionName = doc.Application.VersionName;
                v.Components = new Components();

                var visibleElmes = new FilteredElementCollector(doc, doc.ActiveView.Id)
                    .WhereElementIsNotElementType().WhereElementIsViewIndependent()
                    .ToElementIds();

                var hiddenElems = new FilteredElementCollector(doc)
                    .WhereElementIsNotElementType().WhereElementIsViewIndependent()
                    .Where(x => x.IsHidden(doc.ActiveView) || !doc.ActiveView
                    .IsElementVisibleInTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate,
                    x.Id)).ToList();

                var selectedElemsId = uidoc.Selection.GetElementIds();
                if (selectedElemsId.Any())
                {
                    foreach (var elem in selectedElemsId)
                    {
                        v.Components.Selection.Add(new Component
                        {
                            OriginatingSystem = versionName,
                            IfcGuid = IfcGuid.ToIfcGuid(ExportUtils.GetExportId(doc, elem)),
                            AuthoringToolId = elem.IntegerValue.ToString()
                        });
                    }
                }
                
                // include only hidden elements and selected in the BCF
                if(visibleElmes.Count() > hiddenElems.Count())
                {
                    v.Components.Visibility = new ComponentVisibility();
                    v.Components.Visibility.DefaultVisibility = true;
                    v.Components.Visibility.Exceptions = new List<Component>();
                    foreach(var elem in hiddenElems)
                    {
                        v.Components.Visibility.Exceptions.Add(new Component
                        {
                            OriginatingSystem = versionName,
                            IfcGuid = IfcGuid.ToIfcGuid(ExportUtils.GetExportId(doc,elem.Id)),
                            AuthoringToolId = elem.Id.IntegerValue.ToString()
                            
                        });
                    }

                    
                }
                else
                {
                    v.Components.Visibility.DefaultVisibility = false;
                    foreach(var elem in visibleElmes)
                    {
                        v.Components.Visibility.Exceptions.Add(new Component
                        {
                            OriginatingSystem = versionName,
                            IfcGuid = IfcGuid.ToIfcGuid(ExportUtils.GetExportId(doc, elem)),
                            AuthoringToolId = elem.IntegerValue.ToString()
                        });

                    }
                }
            
            return v;
            }
            catch(Exception ex)
            {
                TaskDialog.Show("Error generating viewpoint", "exception: " + ex);
                return null;
            }
            
        }

  

       public static Image GetRevitSnapshot(UIDocument uidoc)
        {
            Document doc = uidoc.Document;
            string tempImg = Path.Combine(Path.GetTempPath(),  Path.GetTempFileName() + ".png");
            
            try
            {
                
                var options = new ImageExportOptions
                {
                    FilePath = tempImg,
                    HLRandWFViewsFileType = ImageFileType.PNG,
                    ShadowViewsFileType = ImageFileType.PNG,
                    ExportRange = ExportRange.VisibleRegionOfCurrentView,
                    ZoomType = ZoomFitType.FitToPage,
                    ImageResolution = ImageResolution.DPI_72,
                    PixelSize = 1000
                };
                doc.ExportImage(options);
                

               // File.Delete(tempImg);
                
            }
            catch (System.Exception ex1)
            {
                TaskDialog.Show("Error!", "exception: " + ex1);
               
            }
            Bitmap bmpScreenShot = new Bitmap(tempImg);
            return bmpScreenShot;
        }

    }
}
