﻿using BCF_Revit_Addin.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;

namespace BCF_Revit_Addin
{
    public partial class BcfRevitStartForm : Form
    {
        public BcfRevitStartForm()
        {
            InitializeComponent();
        }


        private void BcfRevitStart_Load(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_laden_Click(object sender, EventArgs e)
        {
            var fileManager = new BCFFileManager();
            fileManager.bcfFileLoad(lb_bcfFileLoad);
            
        }

        private void btn_newTopic_Click(object sender, EventArgs e)
        {
            pnl_bcfViewer.Visible = true;

            //int screenWidth = Screen.GetBounds(new Point(0, 0)).Width;
            //int screenHeight = Screen.GetBounds(new Point(0, 0)).Height;
            //Bitmap bmpScreenShot = new Bitmap(screenWidth, screenHeight);
            //Graphics gfx = Graphics.FromImage((Image)bmpScreenShot);
            //gfx.CopyFromScreen(0, 0, 0, 0, new Size(screenWidth, screenHeight));
            //bmpScreenShot.Save("test.jpg", ImageFormat.Jpeg);

            
        }
    }
}
