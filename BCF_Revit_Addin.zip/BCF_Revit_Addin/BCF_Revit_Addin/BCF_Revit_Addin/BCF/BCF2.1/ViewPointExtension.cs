﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCF_Revit_Addin.BCF.BCF2._1
{
    // To store the deserialized VisualizationInfo here(inside the markup), so there is 1 to 1 
    // corrispondence between the Markup/viewpoints Tag and the actual Viewpoints(Visinfo)
    // and don't have to add any new class (the function of partial class)
   public partial class ViewPoint
    {
        private VisualizationInfo _visInfoField;

        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public VisualizationInfo VisInfo
        {
            get
            {
                return this._visInfoField;
            }
            set
            {
                this._visInfoField = value;
            }
        }

        private string _snapshotPath;

        //used for an easier binding in the UI
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public string SnapshotPath
        {
            get
            {
                return this._snapshotPath;
            }
            set
            {
                this._snapshotPath = value;
                //NotifyPropertyChanged("SnapshotPath");
            }
        }

    }
}
