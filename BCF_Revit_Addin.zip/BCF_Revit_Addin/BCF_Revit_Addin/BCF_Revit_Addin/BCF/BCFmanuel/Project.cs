﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCF_Revit_Addin.BCF.BCFmanuel
{

    public partial class ProjectExtension
    {
        // Node
        private Project projectField;
        private string extensionSchemaField; // Typ in xml: anyURI

        public Project Project 
        {
            get
            {
                return projectField;
            }

            set
            {
                projectField = value;
            }
        }

        public string ExtensionSchema 
        {
            get
            {
                return extensionSchemaField;
            }

            set
            {
                extensionSchemaField = value;
            }
        }
    }
    public partial class Project
    {
        // Attribute
        private string projectIdField;
        // Node
        private string nameField;
       

        public string Name 
        {
            get
            {
                return nameField;
            }

            set
            {
                nameField = value;
            }
        }

        public string ProjectId 
        {
            get
            {
                return projectIdField;
            }

            set
            {
                projectIdField = value;
            }
        }
    }


   


}
