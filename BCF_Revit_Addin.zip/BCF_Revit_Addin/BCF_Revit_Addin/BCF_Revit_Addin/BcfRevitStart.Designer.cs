﻿namespace BCF_Revit_Addin
{
    partial class BcfRevitStartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_menuBar = new System.Windows.Forms.Panel();
            this.btn_help = new System.Windows.Forms.Button();
            this.btn_setting = new System.Windows.Forms.Button();
            this.btn_merge = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_laden = new System.Windows.Forms.Button();
            this.btn_newTopic = new System.Windows.Forms.Button();
            this.pnl_bcfList = new System.Windows.Forms.Panel();
            this.lb_bcfFileLoad = new System.Windows.Forms.ListBox();
            this.pnl_bcfViewer = new System.Windows.Forms.Panel();
            this.pnl_comments = new System.Windows.Forms.Panel();
            this.btn_commentsPost = new System.Windows.Forms.Button();
            this.rtb_comments = new System.Windows.Forms.RichTextBox();
            this.btn_deleteComments = new System.Windows.Forms.Button();
            this.btn_editComments = new System.Windows.Forms.Button();
            this.dgv_comments = new System.Windows.Forms.DataGridView();
            this.pcb_screenshot = new System.Windows.Forms.PictureBox();
            this.pnl_bcfTopic = new System.Windows.Forms.Panel();
            this.btn_snippetApply = new System.Windows.Forms.Button();
            this.btn_snippetCreate = new System.Windows.Forms.Button();
            this.lbl_bimSnippet = new System.Windows.Forms.Label();
            this.clb_label = new System.Windows.Forms.CheckedListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_assignto = new System.Windows.Forms.ComboBox();
            this.lbl_assignTo = new System.Windows.Forms.Label();
            this.cb_priority = new System.Windows.Forms.ComboBox();
            this.cb_status = new System.Windows.Forms.ComboBox();
            this.cb_typ = new System.Windows.Forms.ComboBox();
            this.rtb_description = new System.Windows.Forms.RichTextBox();
            this.tb_title = new System.Windows.Forms.TextBox();
            this.lbl_proority = new System.Windows.Forms.Label();
            this.lbl_status = new System.Windows.Forms.Label();
            this.lbl_typ = new System.Windows.Forms.Label();
            this.lbl_description = new System.Windows.Forms.Label();
            this.lbl_title = new System.Windows.Forms.Label();
            this.pnl_menuBar.SuspendLayout();
            this.pnl_bcfList.SuspendLayout();
            this.pnl_bcfViewer.SuspendLayout();
            this.pnl_comments.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_comments)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_screenshot)).BeginInit();
            this.pnl_bcfTopic.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_menuBar
            // 
            this.pnl_menuBar.Controls.Add(this.btn_help);
            this.pnl_menuBar.Controls.Add(this.btn_setting);
            this.pnl_menuBar.Controls.Add(this.btn_merge);
            this.pnl_menuBar.Controls.Add(this.btn_save);
            this.pnl_menuBar.Controls.Add(this.btn_laden);
            this.pnl_menuBar.Controls.Add(this.btn_newTopic);
            this.pnl_menuBar.Location = new System.Drawing.Point(11, 8);
            this.pnl_menuBar.Name = "pnl_menuBar";
            this.pnl_menuBar.Size = new System.Drawing.Size(978, 44);
            this.pnl_menuBar.TabIndex = 0;
            // 
            // btn_help
            // 
            this.btn_help.Location = new System.Drawing.Point(907, 4);
            this.btn_help.Name = "btn_help";
            this.btn_help.Size = new System.Drawing.Size(59, 31);
            this.btn_help.TabIndex = 6;
            this.btn_help.Text = "Help";
            this.btn_help.UseVisualStyleBackColor = true;
            // 
            // btn_setting
            // 
            this.btn_setting.Location = new System.Drawing.Point(816, 4);
            this.btn_setting.Name = "btn_setting";
            this.btn_setting.Size = new System.Drawing.Size(85, 31);
            this.btn_setting.TabIndex = 5;
            this.btn_setting.Text = "Setting";
            this.btn_setting.UseVisualStyleBackColor = true;
            // 
            // btn_merge
            // 
            this.btn_merge.Location = new System.Drawing.Point(97, 3);
            this.btn_merge.Name = "btn_merge";
            this.btn_merge.Size = new System.Drawing.Size(85, 31);
            this.btn_merge.TabIndex = 4;
            this.btn_merge.Text = "Merge";
            this.btn_merge.UseVisualStyleBackColor = true;
            // 
            // btn_save
            // 
            this.btn_save.Location = new System.Drawing.Point(551, 4);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(85, 31);
            this.btn_save.TabIndex = 3;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            // 
            // btn_laden
            // 
            this.btn_laden.Location = new System.Drawing.Point(4, 4);
            this.btn_laden.Name = "btn_laden";
            this.btn_laden.Size = new System.Drawing.Size(85, 31);
            this.btn_laden.TabIndex = 2;
            this.btn_laden.Text = "BCF laden...";
            this.btn_laden.UseVisualStyleBackColor = true;
            this.btn_laden.Click += new System.EventHandler(this.btn_laden_Click);
            // 
            // btn_newTopic
            // 
            this.btn_newTopic.Location = new System.Drawing.Point(464, 4);
            this.btn_newTopic.Name = "btn_newTopic";
            this.btn_newTopic.Size = new System.Drawing.Size(81, 31);
            this.btn_newTopic.TabIndex = 1;
            this.btn_newTopic.Text = "New Topic";
            this.btn_newTopic.UseVisualStyleBackColor = true;
            this.btn_newTopic.Click += new System.EventHandler(this.btn_newTopic_Click);
            // 
            // pnl_bcfList
            // 
            this.pnl_bcfList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_bcfList.Controls.Add(this.lb_bcfFileLoad);
            this.pnl_bcfList.Location = new System.Drawing.Point(11, 58);
            this.pnl_bcfList.Name = "pnl_bcfList";
            this.pnl_bcfList.Size = new System.Drawing.Size(182, 587);
            this.pnl_bcfList.TabIndex = 2;
            // 
            // lb_bcfFileLoad
            // 
            this.lb_bcfFileLoad.FormattingEnabled = true;
            this.lb_bcfFileLoad.Location = new System.Drawing.Point(3, 6);
            this.lb_bcfFileLoad.Name = "lb_bcfFileLoad";
            this.lb_bcfFileLoad.Size = new System.Drawing.Size(172, 576);
            this.lb_bcfFileLoad.TabIndex = 0;
            this.lb_bcfFileLoad.SelectedIndexChanged += new System.EventHandler(this.lb_bcfFileLoad_SelectedIndexChanged);
            // 
            // pnl_bcfViewer
            // 
            this.pnl_bcfViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_bcfViewer.Controls.Add(this.pnl_comments);
            this.pnl_bcfViewer.Controls.Add(this.pcb_screenshot);
            this.pnl_bcfViewer.Controls.Add(this.pnl_bcfTopic);
            this.pnl_bcfViewer.Location = new System.Drawing.Point(199, 58);
            this.pnl_bcfViewer.Name = "pnl_bcfViewer";
            this.pnl_bcfViewer.Size = new System.Drawing.Size(793, 587);
            this.pnl_bcfViewer.TabIndex = 3;
            this.pnl_bcfViewer.Visible = false;
            // 
            // pnl_comments
            // 
            this.pnl_comments.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_comments.Controls.Add(this.btn_commentsPost);
            this.pnl_comments.Controls.Add(this.rtb_comments);
            this.pnl_comments.Controls.Add(this.btn_deleteComments);
            this.pnl_comments.Controls.Add(this.btn_editComments);
            this.pnl_comments.Controls.Add(this.dgv_comments);
            this.pnl_comments.Location = new System.Drawing.Point(4, 326);
            this.pnl_comments.Name = "pnl_comments";
            this.pnl_comments.Size = new System.Drawing.Size(786, 246);
            this.pnl_comments.TabIndex = 3;
            // 
            // btn_commentsPost
            // 
            this.btn_commentsPost.Location = new System.Drawing.Point(698, 137);
            this.btn_commentsPost.Name = "btn_commentsPost";
            this.btn_commentsPost.Size = new System.Drawing.Size(75, 23);
            this.btn_commentsPost.TabIndex = 17;
            this.btn_commentsPost.Text = "Post";
            this.btn_commentsPost.UseVisualStyleBackColor = true;
            // 
            // rtb_comments
            // 
            this.rtb_comments.Location = new System.Drawing.Point(365, 10);
            this.rtb_comments.Name = "rtb_comments";
            this.rtb_comments.Size = new System.Drawing.Size(408, 119);
            this.rtb_comments.TabIndex = 7;
            this.rtb_comments.Text = "";
            // 
            // btn_deleteComments
            // 
            this.btn_deleteComments.Location = new System.Drawing.Point(188, 220);
            this.btn_deleteComments.Name = "btn_deleteComments";
            this.btn_deleteComments.Size = new System.Drawing.Size(75, 23);
            this.btn_deleteComments.TabIndex = 4;
            this.btn_deleteComments.Text = "<<Delete";
            this.btn_deleteComments.UseVisualStyleBackColor = true;
            // 
            // btn_editComments
            // 
            this.btn_editComments.Location = new System.Drawing.Point(277, 220);
            this.btn_editComments.Name = "btn_editComments";
            this.btn_editComments.Size = new System.Drawing.Size(75, 23);
            this.btn_editComments.TabIndex = 3;
            this.btn_editComments.Text = "<<Edit";
            this.btn_editComments.UseVisualStyleBackColor = true;
            // 
            // dgv_comments
            // 
            this.dgv_comments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_comments.Location = new System.Drawing.Point(3, 10);
            this.dgv_comments.Name = "dgv_comments";
            this.dgv_comments.Size = new System.Drawing.Size(349, 207);
            this.dgv_comments.TabIndex = 2;
            // 
            // pcb_screenshot
            // 
            this.pcb_screenshot.Location = new System.Drawing.Point(4, 4);
            this.pcb_screenshot.Name = "pcb_screenshot";
            this.pcb_screenshot.Size = new System.Drawing.Size(352, 316);
            this.pcb_screenshot.TabIndex = 1;
            this.pcb_screenshot.TabStop = false;
            // 
            // pnl_bcfTopic
            // 
            this.pnl_bcfTopic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_bcfTopic.Controls.Add(this.btn_snippetApply);
            this.pnl_bcfTopic.Controls.Add(this.btn_snippetCreate);
            this.pnl_bcfTopic.Controls.Add(this.lbl_bimSnippet);
            this.pnl_bcfTopic.Controls.Add(this.clb_label);
            this.pnl_bcfTopic.Controls.Add(this.label1);
            this.pnl_bcfTopic.Controls.Add(this.cb_assignto);
            this.pnl_bcfTopic.Controls.Add(this.lbl_assignTo);
            this.pnl_bcfTopic.Controls.Add(this.cb_priority);
            this.pnl_bcfTopic.Controls.Add(this.cb_status);
            this.pnl_bcfTopic.Controls.Add(this.cb_typ);
            this.pnl_bcfTopic.Controls.Add(this.rtb_description);
            this.pnl_bcfTopic.Controls.Add(this.tb_title);
            this.pnl_bcfTopic.Controls.Add(this.lbl_proority);
            this.pnl_bcfTopic.Controls.Add(this.lbl_status);
            this.pnl_bcfTopic.Controls.Add(this.lbl_typ);
            this.pnl_bcfTopic.Controls.Add(this.lbl_description);
            this.pnl_bcfTopic.Controls.Add(this.lbl_title);
            this.pnl_bcfTopic.Location = new System.Drawing.Point(362, 4);
            this.pnl_bcfTopic.Name = "pnl_bcfTopic";
            this.pnl_bcfTopic.Size = new System.Drawing.Size(428, 316);
            this.pnl_bcfTopic.TabIndex = 0;
            // 
            // btn_snippetApply
            // 
            this.btn_snippetApply.Location = new System.Drawing.Point(168, 284);
            this.btn_snippetApply.Name = "btn_snippetApply";
            this.btn_snippetApply.Size = new System.Drawing.Size(75, 23);
            this.btn_snippetApply.TabIndex = 17;
            this.btn_snippetApply.Text = "Apply";
            this.btn_snippetApply.UseVisualStyleBackColor = true;
            // 
            // btn_snippetCreate
            // 
            this.btn_snippetCreate.Location = new System.Drawing.Point(75, 284);
            this.btn_snippetCreate.Name = "btn_snippetCreate";
            this.btn_snippetCreate.Size = new System.Drawing.Size(75, 23);
            this.btn_snippetCreate.TabIndex = 16;
            this.btn_snippetCreate.Text = "Create";
            this.btn_snippetCreate.UseVisualStyleBackColor = true;
            // 
            // lbl_bimSnippet
            // 
            this.lbl_bimSnippet.AutoSize = true;
            this.lbl_bimSnippet.Location = new System.Drawing.Point(4, 289);
            this.lbl_bimSnippet.Name = "lbl_bimSnippet";
            this.lbl_bimSnippet.Size = new System.Drawing.Size(65, 13);
            this.lbl_bimSnippet.TabIndex = 14;
            this.lbl_bimSnippet.Text = "BIMSnippet:";
            // 
            // clb_label
            // 
            this.clb_label.FormattingEnabled = true;
            this.clb_label.Location = new System.Drawing.Point(266, 189);
            this.clb_label.Name = "clb_label";
            this.clb_label.Size = new System.Drawing.Size(149, 49);
            this.clb_label.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(207, 187);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Label:";
            // 
            // cb_assignto
            // 
            this.cb_assignto.FormattingEnabled = true;
            this.cb_assignto.Location = new System.Drawing.Point(266, 157);
            this.cb_assignto.Name = "cb_assignto";
            this.cb_assignto.Size = new System.Drawing.Size(149, 21);
            this.cb_assignto.TabIndex = 11;
            // 
            // lbl_assignTo
            // 
            this.lbl_assignTo.AutoSize = true;
            this.lbl_assignTo.Location = new System.Drawing.Point(207, 160);
            this.lbl_assignTo.Name = "lbl_assignTo";
            this.lbl_assignTo.Size = new System.Drawing.Size(53, 13);
            this.lbl_assignTo.TabIndex = 10;
            this.lbl_assignTo.Text = "Assign to:";
            // 
            // cb_priority
            // 
            this.cb_priority.FormattingEnabled = true;
            this.cb_priority.Location = new System.Drawing.Point(70, 215);
            this.cb_priority.Name = "cb_priority";
            this.cb_priority.Size = new System.Drawing.Size(121, 21);
            this.cb_priority.TabIndex = 9;
            // 
            // cb_status
            // 
            this.cb_status.FormattingEnabled = true;
            this.cb_status.Location = new System.Drawing.Point(70, 184);
            this.cb_status.Name = "cb_status";
            this.cb_status.Size = new System.Drawing.Size(121, 21);
            this.cb_status.TabIndex = 8;
            // 
            // cb_typ
            // 
            this.cb_typ.FormattingEnabled = true;
            this.cb_typ.Location = new System.Drawing.Point(70, 157);
            this.cb_typ.Name = "cb_typ";
            this.cb_typ.Size = new System.Drawing.Size(121, 21);
            this.cb_typ.TabIndex = 7;
            // 
            // rtb_description
            // 
            this.rtb_description.Location = new System.Drawing.Point(70, 41);
            this.rtb_description.Name = "rtb_description";
            this.rtb_description.Size = new System.Drawing.Size(345, 80);
            this.rtb_description.TabIndex = 6;
            this.rtb_description.Text = "";
            // 
            // tb_title
            // 
            this.tb_title.Location = new System.Drawing.Point(70, 8);
            this.tb_title.Name = "tb_title";
            this.tb_title.Size = new System.Drawing.Size(345, 20);
            this.tb_title.TabIndex = 5;
            this.tb_title.TextChanged += new System.EventHandler(this.tb_title_TextChanged);
            // 
            // lbl_proority
            // 
            this.lbl_proority.AutoSize = true;
            this.lbl_proority.Location = new System.Drawing.Point(4, 218);
            this.lbl_proority.Name = "lbl_proority";
            this.lbl_proority.Size = new System.Drawing.Size(41, 13);
            this.lbl_proority.TabIndex = 4;
            this.lbl_proority.Text = "Priority:";
            // 
            // lbl_status
            // 
            this.lbl_status.AutoSize = true;
            this.lbl_status.Location = new System.Drawing.Point(4, 189);
            this.lbl_status.Name = "lbl_status";
            this.lbl_status.Size = new System.Drawing.Size(40, 13);
            this.lbl_status.TabIndex = 3;
            this.lbl_status.Text = "Status:";
            // 
            // lbl_typ
            // 
            this.lbl_typ.AutoSize = true;
            this.lbl_typ.Location = new System.Drawing.Point(4, 157);
            this.lbl_typ.Name = "lbl_typ";
            this.lbl_typ.Size = new System.Drawing.Size(28, 13);
            this.lbl_typ.TabIndex = 2;
            this.lbl_typ.Text = "Typ:";
            // 
            // lbl_description
            // 
            this.lbl_description.AutoSize = true;
            this.lbl_description.Location = new System.Drawing.Point(4, 40);
            this.lbl_description.Name = "lbl_description";
            this.lbl_description.Size = new System.Drawing.Size(63, 13);
            this.lbl_description.TabIndex = 1;
            this.lbl_description.Text = "Description:";
            // 
            // lbl_title
            // 
            this.lbl_title.AutoSize = true;
            this.lbl_title.Location = new System.Drawing.Point(4, 8);
            this.lbl_title.Name = "lbl_title";
            this.lbl_title.Size = new System.Drawing.Size(30, 13);
            this.lbl_title.TabIndex = 0;
            this.lbl_title.Text = "Title:";
            // 
            // BcfRevitStartForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(994, 657);
            this.Controls.Add(this.pnl_bcfViewer);
            this.Controls.Add(this.pnl_bcfList);
            this.Controls.Add(this.pnl_menuBar);
            this.Name = "BcfRevitStartForm";
            this.Text = "BCF Manager";
            this.Load += new System.EventHandler(this.BcfRevitStart_Load);
            this.pnl_menuBar.ResumeLayout(false);
            this.pnl_bcfList.ResumeLayout(false);
            this.pnl_bcfViewer.ResumeLayout(false);
            this.pnl_comments.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_comments)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcb_screenshot)).EndInit();
            this.pnl_bcfTopic.ResumeLayout(false);
            this.pnl_bcfTopic.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_menuBar;
        private System.Windows.Forms.Button btn_help;
        private System.Windows.Forms.Button btn_setting;
        private System.Windows.Forms.Button btn_merge;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_laden;
        private System.Windows.Forms.Button btn_newTopic;
        private System.Windows.Forms.Panel pnl_bcfList;
        private System.Windows.Forms.Panel pnl_bcfViewer;
        private System.Windows.Forms.PictureBox pcb_screenshot;
        private System.Windows.Forms.Panel pnl_bcfTopic;
        private System.Windows.Forms.CheckedListBox clb_label;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_assignto;
        private System.Windows.Forms.Label lbl_assignTo;
        private System.Windows.Forms.ComboBox cb_priority;
        private System.Windows.Forms.ComboBox cb_status;
        private System.Windows.Forms.ComboBox cb_typ;
        private System.Windows.Forms.RichTextBox rtb_description;
        private System.Windows.Forms.TextBox tb_title;
        private System.Windows.Forms.Label lbl_proority;
        private System.Windows.Forms.Label lbl_status;
        private System.Windows.Forms.Label lbl_typ;
        private System.Windows.Forms.Label lbl_description;
        private System.Windows.Forms.Label lbl_title;
        private System.Windows.Forms.Panel pnl_comments;
        private System.Windows.Forms.Button btn_commentsPost;
        private System.Windows.Forms.RichTextBox rtb_comments;
        private System.Windows.Forms.Button btn_deleteComments;
        private System.Windows.Forms.Button btn_editComments;
        private System.Windows.Forms.DataGridView dgv_comments;
        private System.Windows.Forms.Button btn_snippetApply;
        private System.Windows.Forms.Button btn_snippetCreate;
        private System.Windows.Forms.Label lbl_bimSnippet;
        private System.Windows.Forms.ListBox lb_bcfFileLoad;
    }
}