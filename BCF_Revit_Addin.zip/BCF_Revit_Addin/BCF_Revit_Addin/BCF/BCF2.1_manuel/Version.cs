﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCF_Revit_Addin.BCF.BCF2._1
{
    public class Version
    {
        // Attribute
        private string versionIdField;

        //Node
        private string detailedVersionField;

        public string VersionIdField
        {
            get
            {
                return versionIdField;
            }

            set
            {
                versionIdField = value;
            }
        }

        public string DetailedVersionField
        {
            get
            {
                return detailedVersionField;
            }

            set
            {
                detailedVersionField = value;
            }
        }
    }
}
