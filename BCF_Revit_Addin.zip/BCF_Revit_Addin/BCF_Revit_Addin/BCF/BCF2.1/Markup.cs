﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCF_Revit_Addin.BCF.BCF2._1
{
    public class Markup
    {
        private List<HeaderFile> headersField;
        private Topic topicField;
        // -----not sure about the datentyp, if its nessesary to use ObsrvableCollaction for 
        // BimSnippet, DR, RT
        private ObservableCollection<BimSnippet> bimSnippetsField; // optinal
        private ObservableCollection<DocumentReference> documentReferencesFiled; // optional
        private ObservableCollection<RelatedTopic> relatedTopicsField;// optional
        private ObservableCollection<Comment> commentsField;
        private ObservableCollection<ViewPoint> viewPointsField;

        public Markup()
        {
            Headers = new List<HeaderFile>();
            Topic = new Topic();
            BimSnippets = new ObservableCollection<BimSnippet>();
            DocumentReferences = new ObservableCollection<DocumentReference>();
            RelatedTopics = new ObservableCollection<RelatedTopic>();
            Comments = new ObservableCollection<Comment>();
            ViewPoints = new ObservableCollection<ViewPoint>();

        }

       
        public List<HeaderFile> Headers 
        {
            get
            {
                return headersField;
            }

            set
            {
                headersField = value;
            }
        }

        public Topic Topic 
        {
            get
            {
                return topicField;
            }

            set
            {
                topicField = value;
            }
        }

        public ObservableCollection<BimSnippet> BimSnippets 
        {
            get
            {
                return bimSnippetsField;
            }

            set
            {
                bimSnippetsField = value;
            }
        }

        public ObservableCollection<DocumentReference> DocumentReferences 
        {
            get
            {
                return documentReferencesFiled;
            }

            set
            {
                documentReferencesFiled = value;
            }
        }

        public ObservableCollection<RelatedTopic> RelatedTopics 
        {
            get
            {
                return relatedTopicsField;
            }

            set
            {
                relatedTopicsField = value;
            }
        }

        public ObservableCollection<Comment> Comments 
        {
            get
            {
                return commentsField;
            }

            set
            {
                commentsField = value;
            }
        }

        public ObservableCollection<ViewPoint> ViewPoints 
        {
            get
            {
                return viewPointsField;
            }

            set
            {
                viewPointsField = value;
            }
        }
    }

    public partial class HeaderFile
    {
        // Attribute
        private string ifcProjectField;
        private string ifcSpatialStructureElementField;
        private bool isExternalField; // default=true

        // Node
        private string filenameField;
        private DateTime dateField;  // Datum of the BIM file
        private string referenceField;


        public HeaderFile()
        {
            this.isExternalField = true;
        }
        public string IfcProject
        {
            get { return ifcProjectField; }
            set { ifcProjectField = value; }
        } 

        public string IfcSpatialStructureElement
        {
            get { return ifcSpatialStructureElementField; }
            set { ifcSpatialStructureElementField = value; }
        }

        public bool IsExternal
        {
            get { return isExternalField; }
            set { isExternalField = value; }
        }

        public string Filename
        {
            get { return filenameField; }
            set { filenameField = value; }
        }

        public DateTime Date
        {
            get { return dateField;}
            set { dateField = value; }
        }

        public string Reference
        {
            get { return referenceField; }
            set { referenceField = value; }
        }
    }


    public partial class Topic
    {
        // Attribute
        private string guidField;
        private string topicTypeFiled;
        private string topicStatusField;

        // Node
        private string referenceLinkField;
        private string titleField;
        private string priorityField;
        private string indexFiled;
        private string[] labelsField;
        private DateTime creationDateField;
        private string creationAuthorField;
        private DateTime modifiedDateField;
        private string modifiedAuthorField;
        private DateTime dueDateField;
        private string assignedToField;
        private string descriptionField;
        private string stageField;//-------------------whats that?


        public Topic()
        {
            Guid = System.Guid.NewGuid().ToString();
            CreationDate = DateTime.Now;
            ModifiedDate = CreationDate;
        }


        public string Guid
        {
            get { return guidField; }

            set { guidField = value; }
        }

        public string TopicType
        {
            get { return topicTypeFiled; }

            set { topicTypeFiled = value; }
        }

        public string TopicStatus
        {
            get { return topicStatusField; }

            set { topicStatusField = value; }
        }

        public string ReferenceLink
        {
            get { return referenceLinkField; }

            set { referenceLinkField = value; }
        }

        public string Title
        {
            get { return titleField; }

            set { titleField = value; }
        }

        public string Priority
        {
            get { return priorityField; }

            set { priorityField = value; }
        }

        public string Index
        {
            get { return indexFiled; }

            set { indexFiled = value; }
        }

        public string[] Labels
        {
            get { return labelsField; }

            set { labelsField = value; }
        }

        public DateTime CreationDate
        {
            get { return creationDateField; }

            set { creationDateField = value; }
        }

        public string CreationAuthor
        {
            get { return creationAuthorField; }

            set { creationAuthorField = value; }
        }

        public DateTime ModifiedDate
        {
            get { return modifiedDateField; }

            set { modifiedDateField = value; }
        }

        public string ModifiedAuthor
        {
            get { return modifiedAuthorField; }

            set { modifiedAuthorField = value; }
        }

        public DateTime DueDate
        {
            get { return dueDateField; }

            set { dueDateField = value; }
        }

        public string AssignedTo
        {
            get { return assignedToField; }

            set { assignedToField = value; }
        }

        public string Description
        {
            get { return descriptionField; }

            set { descriptionField = value; }
        }

        public string Stage
        {
            get { return stageField; }

            set { stageField = value; }
        }
    }

    public partial class BimSnippet // optional
    {
        private string snippetTypeField;
        private bool isExternalField; // default=false
        private string referenceFiled;
        private string referenceSchemaField;


        public BimSnippet()
        {
            this.isExternalField = false;
        }


        public string SnippetType
        {
            get { return snippetTypeField; }

            set { snippetTypeField = value; }
        }

        public bool IsExternal
        {
            get { return isExternalField; }

            set { isExternalField = value; }
        }

        public string Reference
        {
            get { return referenceFiled; }

            set { referenceFiled = value; }
        }

        public string ReferenceSchema
        {
            get { return referenceSchemaField; }

            set { referenceSchemaField = value; }
        }

       
        public class DocumentReference // optional
        {
            private string guidField;
            private bool isExternalField; // deefault= false
            private string referencedDocumentField;
            private string descriptionField;


            public DocumentReference()
            {
                this.isExternalField = false;

            }

            public string Guid
            {
                get
                {
                    return guidField;
                }

                set
                {
                    guidField = value;
                }
            }

            public bool IsExternal
            {
                get
                {
                    return isExternalField;
                }

                set
                {
                    isExternalField = value;
                }
            }

            public string ReferencedDocument
            {
                get
                {
                    return referencedDocumentField;
                }

                set
                {
                    referencedDocumentField = value;
                }
            }

            public string Description
            {
                get
                {
                    return descriptionField;
                }

                set
                {
                    descriptionField = value;
                }
            }

        }



    }

    public partial class DocumentReference
    {
        // Attribute
        private string guidField;
        private bool isExternalField; // deffault = false

        // Node
        private string referencedDocumentField;
        private string descriptionField;

        public DocumentReference()
        {
            this.isExternalField = false;
        }

        public string Guid 
        {
            get
            {
                return guidField;
            }

            set
            {
                guidField = value;
            }
        }

        public bool IsExternal 
        {
            get
            {
                return isExternalField;
            }

            set
            {
                isExternalField = value;
            }
        }

        public string ReferencedDocument 
        {
            get
            {
                return referencedDocumentField;
            }

            set
            {
                referencedDocumentField = value;
            }
        }

        public string Description 
        {
            get
            {
                return descriptionField;
            }

            set
            {
                descriptionField = value;
            }
        }
    }

    public partial class RelatedTopic // optional -------------not sure if it schould be list
    {
        private string[] relatedTopicGuidListField;

        public string[] RelatedTopicGuidList
        {
            get { return relatedTopicGuidListField; }

            set { relatedTopicGuidListField = value; }
        }
    }

    public partial class Comment
    {
        // Attribute
        private string guidField;
     
        // Node
        private DateTime dateField;
        private string authorField;
        private string commentTextField; //---- Inhalt
        private CommentViewpoint viewpointGuidField;  // not sure which type it schould be (String/ CommentViewpoint)
        private DateTime modifiedDateField;
        private string modifiedAuthorField;

        // additional
        private CommentTopic commentTopicGuidField;
        private ReplyToComment replyToCommentGuidField;

        public string Guid
        {
            get
            {
                return guidField;
            }

            set
            {
                guidField = value;
            }
        }

        public DateTime Date 
        {
            get
            {
                return dateField;
            }

            set
            {
                dateField = value;
            }
        }

        public string Author
        {
            get
            {
                return authorField;
            }

            set
            {
                authorField = value;
            }
        }

        public string CommentText
        {
            get
            {
                return commentTextField;
            }

            set
            {
                commentTextField = value;
            }
        }

        public CommentViewpoint ViewpointGuid
        {
            get
            {
                return viewpointGuidField;
            }

            set
            {
                viewpointGuidField = value;
            }
        }

        public DateTime ModifiedDate
        {
            get
            {
                return modifiedDateField;
            }

            set
            {
                modifiedDateField = value;
            }
        }

        public string ModifiedAuthor
        {
            get
            {
                return modifiedAuthorField;
            }

            set
            {
                modifiedAuthorField = value;
            }
        }

        public CommentTopic CommentTopicGuid 
        {
            get
            {
                return commentTopicGuidField;
            }

            set
            {
                commentTopicGuidField = value;
            }
        }

        public ReplyToComment ReplyToCommentGuid 
        {
            get
            {
                return replyToCommentGuidField;
            }

            set
            {
                replyToCommentGuidField = value;
            }
        }
    }

    public partial class CommentViewpoint
    {
        private string guidField;

        public string Guid
        {
            get
            {
                return guidField;
            }

            set
            {
                guidField = value;
            }
        }
    }

    public partial class CommentTopic
    {
        private string guidField;

        public string Guid
        {
            get
            {
                return guidField;
            }

            set
            {
                guidField = value;
            }
        }
    }

    public partial class ReplyToComment
    {
        private string guidField;

        public string Guid
        {
            get
            {
                return guidField;
            }

            set
            {
                guidField = value;
            }
        }
    }


    public partial class ViewPoint // immutable, should never be changed once created
    {
        // Attribute
        private string guidField;

        // Node
        private string viewPointNameField;
        private string snapShotNameField;
        private int indexField;

        public string Guid 
        {
            get
            {
                return guidField;
            }

            set
            {
                guidField = value;
            }
        }

        public string ViewPointName 
        {
            get
            {
                return viewPointNameField;
            }

            set
            {
                viewPointNameField = value;
            }
        }

        public string SnapShotName 
        {
            get
            {
                return snapShotNameField;
            }

            set
            {
                snapShotNameField = value;
            }
        }

        public int Index 
        {
            get
            {
                return indexField;
            }

            set
            {
                indexField = value;
            }
        }
    }





}
