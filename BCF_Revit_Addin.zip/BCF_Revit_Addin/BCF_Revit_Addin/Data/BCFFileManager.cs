﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;

namespace BCF_Revit_Addin.Data
{
    public class BCFFileManager
    {
        public void bcfFileLoad (ListBox lb_bcfFileLoad)
        {
            Stream bcfFileStream = null;
            OpenFileDialog bcfPfadDialog = new OpenFileDialog();

            bcfPfadDialog.InitialDirectory = "c:\\";
            bcfPfadDialog.Filter = "BCF File (*.bcfzip)|*.bcfzip|All files (*.*)|*.*";
            bcfPfadDialog.FilterIndex = 2;
            bcfPfadDialog.RestoreDirectory = true;
            bcfPfadDialog.Multiselect = true;

            if (bcfPfadDialog.ShowDialog() == DialogResult.OK)
            {
                List<String> fullFileName = new List<string>(bcfPfadDialog.FileNames);

                foreach (string filename in fullFileName)
                {
                    lb_bcfFileLoad.Items.Add(filename.Substring(filename.LastIndexOf(@"\") + 1));
                }
                try
                {
                    if ((bcfFileStream = bcfPfadDialog.OpenFile()) != null)
                    {

                        using (bcfFileStream)
                        {
                            // Insert code to read the stream here.

                        }

                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);

                }
            }
        }



    }
}
