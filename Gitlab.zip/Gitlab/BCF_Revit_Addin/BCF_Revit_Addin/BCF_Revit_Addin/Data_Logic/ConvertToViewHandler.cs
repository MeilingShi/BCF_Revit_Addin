﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using BCF_Revit_Addin.BCF.BCF2._1;
using System.Windows;

namespace BCF_Revit_Addin.Data_Logic 
{

    public class ConvertToViewHandler : IExternalEventHandler
    {
   
        public VisualizationInfo v;
        /// <summary>
        /// External Event Implementation
        /// </summary>
        /// <param name="app"></param>
        /// 

        public void Execute(UIApplication app)
        {
            try
            {
                UIDocument uidoc = app.ActiveUIDocument;
                Document doc = uidoc.Document;
                //var uniqueView = UserSettings.GetBool("alwaysNewView");
                var uniqueView = false;


                // Is Orthogonal
                if (v.OrthogonalCamera != null)
                {
                    if (v.OrthogonalCamera.CameraViewPoint == null || v.OrthogonalCamera.CameraUpVector == null
                        || v.OrthogonalCamera.CameraDirection == null)
                        return;
                    var zoom = v.OrthogonalCamera.ViewToWorldScale.ToFeet();
                    var cameraDirection = RevitUtils.GetRevitXYZ(v.OrthogonalCamera.CameraDirection);
                    var cameraUpvector = RevitUtils.GetRevitXYZ(v.OrthogonalCamera.CameraUpVector);
                    var cameraViewPoint = RevitUtils.GetRevitXYZ(v.OrthogonalCamera.CameraViewPoint);
                    var orient3D = RevitUtils.ConvertBasePoint(doc, cameraViewPoint, cameraDirection, cameraUpvector, true);

                    View3D orthoView = null;
                    if (doc.ActiveView.ViewType == ViewType.ThreeD)
                    {
                        var activeView3D = doc.ActiveView as View3D;
                        if (!activeView3D.IsPerspective)
                            orthoView = activeView3D;
                    }
                    else if (orthoView == null)
                    {
                        // try to use an exsisting 3D view
                        IEnumerable<View3D> viewcollector3D = get3DViews(doc);
                        if (viewcollector3D.Any(o => o.Name == "{3D}" || o.Name == "BCFortho"))
                            orthoView = viewcollector3D.First(o => o.Name == "{3D}" || o.Name == "BCFortho");
                    }

                    using (var trans = new Transaction(uidoc.Document))
                    {

                        if (trans.Start("open orthogonal view") == TransactionStatus.Started)
                        {
                            // create a new 3d ortho view
                            if (orthoView == null || uniqueView)
                            {
                                orthoView = View3D.CreateIsometric(doc, getFamilyViews(doc).First().Id);
                                orthoView.Name = (uniqueView) ? "BCFortho" + DateTime.Now.ToString("yyyyMMddTHHmmss") : "BCFortho";
                                
                            }
                            else
                            {
                                //reusing an existing view, I net to reset the visibility
                                //placed this here because if set afterwards it doesn't work
                                orthoView.DisableTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate);
                                
                            }
                            orthoView.SetOrientation(orient3D);
                            trans.Commit();

                        }

                    }
                    uidoc.ActiveView = orthoView;

                    double x = zoom;
                    // set UI view position and zoom
                    XYZ m_xyzTl = uidoc.ActiveView.Origin.Add(uidoc.ActiveView.UpDirection.Multiply(x)).Subtract(uidoc.ActiveView.RightDirection.Multiply(x));
                    XYZ m_xyzBr = uidoc.ActiveView.Origin.Subtract(uidoc.ActiveView.UpDirection.Multiply(x)).Add(uidoc.ActiveView.RightDirection.Multiply(x));
                    uidoc.GetOpenUIViews().First().ZoomAndCenterRectangle(m_xyzTl, m_xyzBr);


                }
                else return;


                if (v.Components != null && v.Components.Selection.Any())
                {
                    var elementsToSelect = new List<ElementId>();
                    var elementsToHide = new List<ElementId>();
                    var elementsToShow = new List<ElementId>();

                   // Assuming that
                    var visibleElems = new FilteredElementCollector(doc, doc.ActiveView.Id) // visibleElems: uniqueId in Revit
                   .WhereElementIsNotElementType()
                   .WhereElementIsViewIndependent()
                   .ToElementIds()
                   .Where(e => doc.GetElement(e).CanBeHidden(doc.ActiveView)); 
                    //might affect performance, but it's necessary                                                          
                    // Element.CanBeHidden() 
                    //http://help.autodesk.com/view/RVT/2016/ENU/?guid=GUID-5A0D8870-EC39-43AF-95E5-3C1CFC398606

                    foreach (var e in visibleElems)
                    {
                        //elements to select
                        var guid = IfcGuid.ToIfcGuid(ExportUtils.GetExportId(doc, e));
                        if (v.Components.Selection.Any(x => x.IfcGuid == guid))
                            elementsToSelect.Add(e);

                        // elements to hide
                        bool visibility = v.Components.Visibility.DefaultVisibility;
                        switch (visibility)
                        {
                            case true:
                            {
                                if (v.Components.Visibility.Exceptions.Any(x => x.IfcGuid == guid))
                                    elementsToHide.Add(e);
                                break;
                            }

                            case false:
                                {
                                    if (v.Components.Visibility.Exceptions.Any(x => x.IfcGuid == guid))
                                        elementsToShow.Add(e);
                                    break;
                                }

                        }
                           
                    }

                    using (var trans = new Transaction(uidoc.Document))
                    {
                        if (trans.Start("Show/Hide and select elements") == TransactionStatus.Started)
                        {
                            if (elementsToHide.Any())
                                doc.ActiveView.HideElementsTemporary(elementsToHide);
                            //there are no items to hide, therefore hide everything and just show the visible ones
                            else if (elementsToShow.Any())
                                doc.ActiveView.IsolateElementsTemporary(elementsToShow);

                            if (elementsToSelect.Any())
                                uidoc.Selection.SetElementIds(elementsToSelect);
                        }
                        trans.Commit();
                    }
                }
                else
                {
                    MessageBox.Show("No selected elements.");
                }


                uidoc.RefreshActiveView();
            }
            catch (Exception ex)
            {
                TaskDialog.Show("Error!", "Exception: " + ex);
            }
        }

        public string GetName()
        {
            return "Open 3D View";
        }


   

        private IEnumerable<View3D> get3DViews(Document doc)
        {
            return from elem in new FilteredElementCollector(doc).OfClass(typeof(View3D))
                   let view = elem as View3D
                   select view;
        }

        // get the View family
        private IEnumerable<ViewFamilyType> getFamilyViews(Document doc)
        {

            return from elem in new FilteredElementCollector(doc).OfClass(typeof(ViewFamilyType))
                   let type = elem as ViewFamilyType
                   where type.ViewFamily == ViewFamily.ThreeDimensional
                   select type;
        }

        
    }
}
