#region Namespaces
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using BCF_Revit_Addin.Data_Logic;
using System.Windows;
using System.Reflection;
#endregion

namespace BCF_Revit_Addin
{

    /// <summary>
    /// Obfuscation Ignore for External Interface
    /// </summary>
    [Obfuscation(Exclude = true, ApplyToMembers = false)]
    [Transaction(TransactionMode.Manual)]
    public class App : IExternalApplication
    {
        //class instance
        public static App thisApp = null;
        // ModelessForm instance
        public BcfRevitStartForm startForm;

        static ExternalEvent extEvent = null;

        public Result OnStartup(UIControlledApplication a)
        {
            startForm = null; // no dialog needed yet; the command will bring it
            thisApp = this; // static access to this application instance
           
            return Result.Succeeded;

        }

        public Result OnShutdown(UIControlledApplication a)
        {
            return Result.Succeeded;
        }

        //   The external command invokes this on the end-user's request
        public void ShowForm(UIApplication uiapp)
        {
            try
            {
                if (startForm != null) return;

                // A new handler to handle request posting by the dialog  
                //var handler = new ConvertToViewHandler();

                var handler = new ConvertToViewHandler();
                ////// External Event for the dialog to use (to post requests)  
                extEvent = ExternalEvent.Create(handler);
     

                // We give the objects to the new dialog;  
                // The dialog becomes the owner responsible for disposing them, eventually.
                startForm = new BcfRevitStartForm(uiapp, extEvent,handler);
                startForm.Show();
            }
            catch(Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }

        /// <summary>
        /// Set Focus
        /// </summary>
        public void Focus()
        {
            try
            {
                if (startForm == null) return;
                startForm.Activate();
                startForm.WindowState = FormWindowState.Normal;
            }
            catch(Exception ex)
            {
                System.Windows.MessageBox.Show(ex.ToString());
            }
        }


    }
}
