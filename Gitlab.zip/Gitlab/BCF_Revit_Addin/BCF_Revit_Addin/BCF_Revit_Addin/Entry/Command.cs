#region Namespaces
using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using BCF_Revit_Addin.Data_Logic;
using System.Reflection;
using System.Linq;
using BCF_Revit_Addin.BCF.BCF2._1;
#endregion

namespace BCF_Revit_Addin
{
    /// <summary>
    /// Obfuscation Ignore for External Interface
    /// </summary>
    [Obfuscation(Exclude = true, ApplyToMembers = false)]
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    [Autodesk.Revit.Attributes.Regeneration(Autodesk.Revit.Attributes.RegenerationOption.Manual)]
    public class Command : IExternalCommand
    {

        internal static Command ThisCmd = null;
        private static bool _isRunning;
        private static App _app;

        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {

            //UIApplication uiapp = commandData.Application;
            //UIDocument uidoc = uiapp.ActiveUIDocument;

            //Document doc = uidoc.Document;

            //Load bcf Api Window
            //App.thisApp.ShowForm(commandData.Application);


            // Access current selection

            //Selection sel = uidoc.Selection;

            // Retrieve elements from database

            //FilteredElementCollector col
            //  = new FilteredElementCollector(doc)
            //    .WhereElementIsNotElementType()
            //    .OfCategory(BuiltInCategory.INVALID)
            //    .OfClass(typeof(Wall));

            // Filtered element collector is iterable

            //foreach (Element e in col)
            //{
            //    Debug.Print(e.Name);
            //}

            // Modify document within a transaction

            //using (Transaction tx = new Transaction(doc))
            //{
            //    tx.Start("Transaction Name");
            //    tx.Commit();
            //}

            try
            {
                if (_isRunning && _app != null && _app.startForm.Modal == true)
                {
                    _app.Focus();
                    return Result.Succeeded;
                }
                _isRunning = true;
                ThisCmd = this;
                _app = new App();
                _app.ShowForm(commandData.Application);
                return Result.Succeeded;

            }
            catch (Exception ex)
            {
                message = ex.Message;
                return Result.Failed;
            }
        }

           
        

    }
}
