﻿using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BCF_Revit_Addin.BCF.BCF2._1
{
    public partial class VisualizationInformation
    {
        private Components commponentsField; // Physical building components, such as walls and doors
        private OrthogonalCamera orthogonalCameraField; 
        private PerspectiveCamera perspectiveCameraField;
        private List<Line> linesField;
        private List<ClippingPlane> clippingPlanesField;
        private List<Bitmap> bitmapsField;

        public VisualizationInformation()
        {

            
        }

     
        
    }

    public partial class Component
    {
        // Attribute
        private string ifcGuidField;
        private bool selectedField;
        private bool visibleField;
        private byte[] colorField; /// color of the component. given in A(lpha)RGB format

        // Node
        private string originatingSystemField;
        private string authoringToolIdField;

        //In oder to keep the component References minimum: See Exporting Components in ViewPoint!

        public Component()
        {
            this.visibleField = true;
        }

       
        public string IfcGuid
        {
            get
            {
                return ifcGuidField;
            }

            set
            {
                ifcGuidField = value;
            }
        }

        public bool Selected
        {
            get
            {
                return selectedField;
            }

            set
            {
                selectedField = value;
            }
        }

        public bool Visible
        {
            get
            {
                return visibleField;
            }

            set
            {
                visibleField = value;
            }
        }

        public byte[] Color
        {
            get
            {
                return colorField;
            }

            set
            {
                colorField = value;
            }
        }

        public string OriginatingSystem
        {
            get
            {
                return originatingSystemField;
            }

            set
            {
                originatingSystemField = value;
            }
        }

        public string AuthoringToolId
        {
            get
            {
                return authoringToolIdField;
            }

            set
            {
                authoringToolIdField = value;
            }
        }
    }


    public partial class Components
    {
        private bool defaultVisibilityComponentsField;
        private bool defaultVisibilitySpaces;
        private bool defaultVisibilitySpaceBoundaries;
        private bool defaultVisibilityOpenings;
        private List<Component> componentsField;

       

        public bool DefaultVisibilityComponentsField
        {
            get
            {
                return defaultVisibilityComponentsField;
            }

            set
            {
                defaultVisibilityComponentsField = value;
            }
        }

        public bool DefaultVisibilitySpaces
        {
            get
            {
                return defaultVisibilitySpaces;
            }

            set
            {
                defaultVisibilitySpaces = value;
            }
        }

        public bool DefaltVisibilitySpaceBoundaries
        {
            get
            {
                return defaultVisibilitySpaceBoundaries;
            }

            set
            {
                defaultVisibilitySpaceBoundaries = value;
            }
        }

        public bool DefaultVisibilityOpenings
        {
            get
            {
                return defaultVisibilityOpenings;
            }

            set
            {
                defaultVisibilityOpenings = value;
            }
        }

        public List<Component> ComponentsField
        {
            get
            {
                return componentsField;
            }

            set
            {
                componentsField = value;
            }
        }
    }






    public partial class Point
    {

        private double xField;

        private double yField;

        private double zField;

        public double X
        {
            get
            {
                return xField;
            }

            set
            {
                xField = value;
            }
        }

        public double Y
        {
            get
            {
                return yField;
            }

            set
            {
                yField = value;
            }
        }

        public double Z
        {
            get
            {
                return zField;
            }

            set
            {
                zField = value;
            }
        }
    }

    public partial class Direction
    {
        private double xField;

        private double yField;

        private double zField;

        public double X
        {
            get
            {
                return xField;
            }

            set
            {
                xField = value;
            }
        }

        public double Y
        {
            get
            {
                return yField;
            }

            set
            {
                yField = value;
            }
        }

        public double Z
        {
            get
            {
                return zField;
            }

            set
            {
                zField = value;
            }
        }
    }

    public partial class OrthogonalCamera
    {
        // Node
        private Point cameraViewPointField;
        private Direction cameraDirectionField;
        private Direction cameraUpVectorField;
        private double viewToWorldScaleField;  // Scaling from view to world?

        public OrthogonalCamera()
        {
            CameraViewPoint = new Point();
            CameraDirection = new Direction();
            CameraUpVector = new Direction();
        }
        public Point CameraViewPoint
        {
            get
            {
                return cameraViewPointField;
            }

            set
            {
                cameraViewPointField = value;
            }
        }

        public Direction CameraDirection
        {
            get
            {
                return cameraDirectionField;
            }

            set
            {
                cameraDirectionField = value;
            }
        }

        public Direction CameraUpVector
        {
            get
            {
                return cameraUpVectorField;
            }

            set
            {
                cameraUpVectorField = value;
            }
        }

        public double ViewToWorldScale
        {
            get
            {
                return viewToWorldScaleField;
            }

            set
            {
                viewToWorldScaleField = value;
            }
        }
    }

    public partial class PerspectiveCamera
    {
        // Node
        private Point cameraViewPointField;
        private Direction cameraDirectionField;
        private Direction cameraUpVectorField;
        private double fieldOfViewField; // Camera's field of view angle in degrees

        public PerspectiveCamera()
        {
            CameraViewPoint = new Point();
            CameraDirection = new Direction();
            CameraUpVector = new Direction();
        }
        public Point CameraViewPoint 
        {
            get
            {
                return cameraViewPointField;
            }

            set
            {
                cameraViewPointField = value;
            }
        }

        public Direction CameraDirection 
        {
            get
            {
                return cameraDirectionField;
            }

            set
            {
                cameraDirectionField = value;
            }
        }

        public Direction CameraUpVector 
        {
            get
            {
                return cameraUpVectorField;
            }

            set
            {
                cameraUpVectorField = value;
            }
        }

        public double FieldOfView 
        {
            get
            {
                return fieldOfViewField;
            }

            set
            {
                fieldOfViewField = value;
            }
        }

    
    }

    // To add Mrkup in 3D Model
    public partial class Line
    {
        private Point startPointField;
        private Point endPointField;

        public Line()
        {
            StartPoint = new Point();
            EndPoint = new Point();
        }

        public Point StartPoint 
        {
            get
            {
                return startPointField;
            }

            set
            {
                startPointField = value;
            }
        }

        public Point EndPoint 
        {
            get
            {
                return endPointField;
            }

            set
            {
                endPointField = value;
            }
        }
    }

    public partial class ClippingPlane // subsection of a building model that is related to the topic
    {
        // Node
        private Point locationField;
        private Direction directionField;

        public ClippingPlane()
        {
            Location = new Point();
            Direction = new Direction();
        }


        public Point Location 
        {
            get
            {
                return locationField;
            }

            set
            {
                locationField = value;
            }
        }

        public Direction Direction 
        {
            get
            {
                return directionField;
            }

            set
            {
                directionField = value;
            }
        }
    }

    public partial class Bitmap
    {
        // node
        private BitmapFormat bitmapField;
        private string referenceField; // name of the bitmap in the topic folder 
        private Point locationField; // location of the center of the bitmap in the world coordinates
        private Direction normalField;
        private Direction upField;
        
    }

    public enum BitmapFormat
    {
        PNG,
        JPG
    }









}
