﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BCF_Revit_Addin.BCF.BCF2._1;

namespace BCF_Revit_Addin.BCF
{
    public class BcfFile
    {
        private Guid id;
        public string TempPath { get; set; }
        public string Fullname { get; set; }
        public Guid ProjectId { get; set; }
        public String ProjectName { get; set; }


        private string _filename;
        private bool _hasBeenSaved;
        private ObservableCollection<Markup> _issues;
        private Markup _selectedIssue;
        private string _textSearch;
        private ListCollectionView _view;
        
        public Guid Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string Filename
        {
            get
            {
                return _filename;
            }

            set
            {
                _filename = value;
            }
        }

        public bool HasBeemSaved
        {
            get
            {
                return _hasBeenSaved;
            }

            set
            {
                _hasBeenSaved = value;
            }
        }

        public ObservableCollection<Markup> Issues
        {
            get
            {
                return _issues;
            }

            set
            {
                _issues = value;
            }
        }

        public Markup SelectedIssue
        {
            get
            {
                return _selectedIssue;
            }

            set
            {
                _selectedIssue = value;
            }
        }

        public string TextSearch
        {
            get
            {
                return _textSearch;
            }

            set
            {
                _textSearch = value;
            }
        }

        public ListCollectionView View
        {
            get
            {
                return _view;
            }

            set
            {
                _view = value;
            }
        }

       
        public BcfFile()
        {
            HasBeemSaved = true;
            Filename = "New BCF Topic";
            Id = Guid.NewGuid();
            TempPath = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "BCFAddin", Id.ToString());
            Issues = new ObservableCollection<Markup>();
            
        }





    }
}
