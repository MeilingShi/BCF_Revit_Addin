﻿using BCF_Revit_Addin.Data;
using BCF_Revit_Addin.BCF;
using BCF_Revit_Addin.BCF.BCF2._1;
using BCF_Revit_Addin.GUI;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using BCF_Revit_Addin.Data_Logic;
using System.Windows.Forms;
using Autodesk.Revit.UI;
using System.IO;
using System.IO.Compression;
using System.Xml.Serialization;
using System.Drawing.Imaging;

namespace BCF_Revit_Addin
{
    public partial class BcfRevitStartForm : System.Windows.Forms.Form
    {
        private UIApplication uiapp;
        private ConvertToViewHandler Handler;
        private ExternalEvent ExtEvent;
        private BCFFileManager fileManager = new BCFFileManager();
        BcfFile selectedBcffile = new BcfFile();
        Markup selectedMarkup = new Markup();

        public BcfRevitStartForm( UIApplication _uiapp, ExternalEvent exEvent, ConvertToViewHandler handler )
        {
            
            InitializeComponent();
            try
            {
                ExtEvent = exEvent;
                Handler = handler;
                uiapp = _uiapp;
            }
            catch(Exception ex1)
            {
                TaskDialog.Show("Error!", "exception: " + ex1);
            }
        }


        private void BcfRevitStart_Load(object sender, EventArgs e)
        {

        }

        private void btn_laden_Click(object sender, EventArgs e)
        {
            
            fileManager.bcfFileLoad(lb_bcfFileLoad);
            
        }

        private void btn_newTopic_Click(object sender, EventArgs e)
        {
            ClearFormFelder();
            pnl_bcfViewer.Visible = true;
            btn_createBcf.Visible = true;
            btn_save.Visible = false;
            


        }

        private void btn_createBcf_Click(object sender, EventArgs e)
        {
            // create bcf as a method writen later 
            BcfFile bcffile = new BcfFile();
            Markup markup = new Markup();

            try
            {

                markup.Topic = new Topic();               
                markup.Topic.Title = string.IsNullOrEmpty(tb_title.Text) ? "Defalt": tb_title.Text;
                markup.Topic.Description = string.IsNullOrEmpty(rtb_description.Text) ? "Default": rtb_description.Text;
                markup.Topic.TopicType = string.IsNullOrEmpty(cb_typ.SelectedItem.ToString()) ? "Default" : cb_typ.SelectedItem.ToString();
                    
                markup.Topic.AssignedTo = string.IsNullOrEmpty(cb_assignto.SelectedItem.ToString()) ? "Defalt": cb_assignto.SelectedItem.ToString();
                markup.Topic.TopicStatus = string.IsNullOrEmpty(cb_status.SelectedItem.ToString()) ? "Default": cb_status.SelectedItem.ToString();
                markup.Topic.Priority = string.IsNullOrEmpty(cb_priority.SelectedItem.ToString()) ? "Default": cb_priority.SelectedItem.ToString();
                markup.Topic.Labels = (clb_label.CheckedItems.Cast<string>().ToList().Count == 0) ? new List<string>() : clb_label.CheckedItems.Cast<string>().ToList();               

                pcb_screenshot.Image =  ScreenshotUtils.GetRevitSnapshot(uiapp.ActiveUIDocument);
                pcb_screenshot.SizeMode = PictureBoxSizeMode.Zoom;


                markup.Viewpoints = new System.Collections.ObjectModel.ObservableCollection<ViewPoint>();

                var viewp = new ViewPoint(!markup.Viewpoints.Any());
                viewp.VisInfo = new VisualizationInfo();
                viewp.VisInfo = ScreenshotUtils.GenerateViewpoint(uiapp.ActiveUIDocument);              

                markup.Viewpoints.Add(viewp);
                bcffile.Filename = markup.Topic.Title;
                bcffile.Issues = new System.Collections.ObjectModel.ObservableCollection<Markup>();
                bcffile.Issues.Add(markup);

                bool resul = BCFFileManager.CreateBcfZip(bcffile,(Bitmap)pcb_screenshot.Image);

                

                if (resul == true)
                
                    System.Windows.MessageBox.Show("Create BcfZip successed!");
               
                else
                    System.Windows.MessageBox.Show("Create BcfZip failed!");
            }
            catch(Exception ex)
            {
                TaskDialog.Show("Exception", ex.ToString());
            }

            btn_createBcf.Visible = false;
            btn_save.Visible = true;
        }


        private void lb_bcfFileLoad_SelectedIndexChanged(object sender, EventArgs e)
        {
            BcfFile bcffile = new BcfFile();
            Markup markup = new Markup();

            pnl_bcfViewer.Visible = true;
            ClearFormFelder();

            string clFilename = ((FullFilename)lb_bcfFileLoad.SelectedItem).FileFullname;
            bcffile = fileManager.OpenBcfFile(clFilename);
            markup = bcffile.SelectedIssue;
            tb_title.Text = markup.Topic.Title;
            rtb_description.Text = markup.Topic.Description;
            cb_typ.Text = markup.Topic.TopicType;
            cb_assignto.Text = markup.Topic.AssignedTo;
            cb_status.Text = markup.Topic.TopicStatus;
            cb_priority.Text = markup.Topic.Priority;
            
            foreach (string l in markup.Topic.Labels)
            {
                
                for (int i =0; i < clb_label.Items.Count; i++)
                {
                    if (l == clb_label.Items[i].ToString())
                        clb_label.SetItemChecked(i, true);
                }
             
            }
            

            if (markup.Topic.Labels != null)
            {
                foreach(var label in markup.Topic.Labels)
                {
                    clb_label.Items.Add(label);
                }
                
            }

            if (markup.Comment!= null)
            {
                dgv_comments.DataSource = GuiLogic.ConvertListToDataTable(markup.Comment);
            }
            
            // hier only the first Snapshot will be displayed--------------------------------------- 
            try
            {
                // read screenshot from temp to stream, then load image from stream to bitmap,
                // not cleaver, but otherwise can't delete temp files when close the window,
                //because screenshot will be used by app
                Image image = Image.FromFile(markup.Viewpoints.First().SnapshotPath);

                MemoryStream stream = new MemoryStream();
                
                // Save image to stream.
                image.Save(stream, ImageFormat.Bmp);
                Bitmap btm = new Bitmap(stream);
                stream.Close(); // importent!
                pcb_screenshot.Image = btm;
                pcb_screenshot.SizeMode = PictureBoxSizeMode.Zoom;
                
                ////Größe des Views anpassen
                //Bitmap image = new Bitmap(markup.Viewpoints.First().SnapshotPath);
                //pcb_screenshot.Image = image;
                //pcb_screenshot.SizeMode = PictureBoxSizeMode.Zoom;

            }
            catch
            {
                pcb_screenshot.Hide();
            }


            // zoom to viewpoint-------------------------------------------------------------------
            try
            {
                Handler.v = markup.Viewpoints.First().VisInfo;
                ExtEvent.Raise();

            }
            catch (Exception ex)
            {
                TaskDialog.Show("Error!", "Exception: " + ex);
            }

            selectedBcffile = bcffile;
            selectedMarkup = markup;

        }

  

       

        private void dgv_comments_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        /// <summary>
        /// Form closed event handler
        /// </summary>
        /// <param name="e"></param>
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            // the form own both the event and the handler
            // we should dispose it before we are closed
            ExtEvent.Dispose();
            ExtEvent = null;
            Handler = null;

            // do not forget to call the base class
            base.OnFormClosed(e);
            BCFFileManager.CloseFile();

        }

        // clear all the inputsfelder
        private void ClearFormFelder()
        {
            tb_title.Text = null;
            tb_title.Clear();

            rtb_description.Text = null;
            rtb_description.Clear();
      
            cb_typ.SelectedItem = null;
            cb_assignto.SelectedItem = null;
            cb_priority.SelectedItem = null;
            cb_status.SelectedItem = null;
            dgv_comments.DataSource = null;
            dgv_comments.Rows.Clear();
            rtb_comments.Clear();
            pcb_screenshot.Image = null;
            pcb_screenshot.Invalidate();
            foreach (int i in clb_label.CheckedIndices)
            {
                clb_label.SetItemCheckState(i, CheckState.Unchecked);
            }


        }

        private void btn_setting_Click(object sender, EventArgs e)
        {
            Setting setForm = new Setting();
            setForm.ShowDialog();

        }

       
        

        private void btn_save_Click(object sender, EventArgs e)
        {
            BcfFile bcffile = selectedBcffile;
            //Markup markup = new Markup();
            Markup m = makeMarkup();
            //m = makeMarkup();

            string issuePath = Path.Combine(bcffile.TempPath, m.Topic.Guid, "markup.bcf");

            bool success = BCFFileManager.SaveMarkup(issuePath,m, bcffile.Fullname);

            if (success == true)
            {
                MessageBox.Show("update successed!");
            }
            
        }

        private Markup makeMarkup ()
        {
            
            Markup markup = selectedMarkup;
            markup.Topic.Title = string.IsNullOrEmpty(tb_title.Text) ? "Defalt" : tb_title.Text;
            markup.Topic.Description = string.IsNullOrEmpty(rtb_description.Text) ? "Default" : rtb_description.Text;
            markup.Topic.TopicType = string.IsNullOrEmpty(cb_typ.SelectedItem.ToString()) ? "Default" : cb_typ.SelectedItem.ToString();

            markup.Topic.AssignedTo = string.IsNullOrEmpty(cb_assignto.SelectedItem.ToString()) ? "Defalt" : cb_assignto.SelectedItem.ToString();
            markup.Topic.TopicStatus = string.IsNullOrEmpty(cb_status.SelectedItem.ToString()) ? "Default" : cb_status.SelectedItem.ToString();
            markup.Topic.Priority = string.IsNullOrEmpty(cb_priority.SelectedItem.ToString()) ? "Default" : cb_priority.SelectedItem.ToString();
            markup.Topic.Labels = (clb_label.CheckedItems.Cast<string>().ToList().Count == 0) ? new List<string>() : clb_label.CheckedItems.Cast<string>().ToList();

            return markup;
        }

        private void pcb_screenshot_Click(object sender, EventArgs e)
        {
       
            if (pcb_screenshot.Dock == DockStyle.None)
            {
                pcb_screenshot.Dock = DockStyle.Fill;
                pcb_screenshot.BringToFront();
            }
            else
                pcb_screenshot.Dock = DockStyle.None;
        }
    }
}
