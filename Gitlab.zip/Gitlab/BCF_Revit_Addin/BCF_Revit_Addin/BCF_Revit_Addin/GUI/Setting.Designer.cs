﻿namespace BCF_Revit_Addin.GUI
{
    partial class Setting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Setting));
            this.tab_setting = new System.Windows.Forms.TabControl();
            this.tabPage_status = new System.Windows.Forms.TabPage();
            this.tabPage_types = new System.Windows.Forms.TabPage();
            this.tabPage_proprity = new System.Windows.Forms.TabPage();
            this.tabPage_labels = new System.Windows.Forms.TabPage();
            this.tab_setting.SuspendLayout();
            this.SuspendLayout();
            // 
            // tab_setting
            // 
            this.tab_setting.Controls.Add(this.tabPage_status);
            this.tab_setting.Controls.Add(this.tabPage_types);
            this.tab_setting.Controls.Add(this.tabPage_proprity);
            this.tab_setting.Controls.Add(this.tabPage_labels);
            this.tab_setting.Location = new System.Drawing.Point(0, 630);
            this.tab_setting.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.tab_setting.Name = "tab_setting";
            this.tab_setting.SelectedIndex = 0;
            this.tab_setting.Size = new System.Drawing.Size(1085, 334);
            this.tab_setting.TabIndex = 0;
            // 
            // tabPage_status
            // 
            this.tabPage_status.Location = new System.Drawing.Point(4, 33);
            this.tabPage_status.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.tabPage_status.Name = "tabPage_status";
            this.tabPage_status.Padding = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.tabPage_status.Size = new System.Drawing.Size(1077, 297);
            this.tabPage_status.TabIndex = 0;
            this.tabPage_status.Text = "Status";
            this.tabPage_status.UseVisualStyleBackColor = true;
            // 
            // tabPage_types
            // 
            this.tabPage_types.Location = new System.Drawing.Point(4, 33);
            this.tabPage_types.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.tabPage_types.Name = "tabPage_types";
            this.tabPage_types.Padding = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.tabPage_types.Size = new System.Drawing.Size(1077, 297);
            this.tabPage_types.TabIndex = 1;
            this.tabPage_types.Text = "Types";
            this.tabPage_types.UseVisualStyleBackColor = true;
            // 
            // tabPage_proprity
            // 
            this.tabPage_proprity.Location = new System.Drawing.Point(4, 33);
            this.tabPage_proprity.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.tabPage_proprity.Name = "tabPage_proprity";
            this.tabPage_proprity.Size = new System.Drawing.Size(1077, 297);
            this.tabPage_proprity.TabIndex = 2;
            this.tabPage_proprity.Text = "Priorities";
            this.tabPage_proprity.UseVisualStyleBackColor = true;
            // 
            // tabPage_labels
            // 
            this.tabPage_labels.Location = new System.Drawing.Point(4, 33);
            this.tabPage_labels.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.tabPage_labels.Name = "tabPage_labels";
            this.tabPage_labels.Size = new System.Drawing.Size(1077, 297);
            this.tabPage_labels.TabIndex = 3;
            this.tabPage_labels.Text = "Labels";
            this.tabPage_labels.UseVisualStyleBackColor = true;
            // 
            // Setting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1107, 1049);
            this.Controls.Add(this.tab_setting);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Setting";
            this.Text = "Setting";
            this.tab_setting.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tab_setting;
        private System.Windows.Forms.TabPage tabPage_status;
        private System.Windows.Forms.TabPage tabPage_types;
        private System.Windows.Forms.TabPage tabPage_proprity;
        private System.Windows.Forms.TabPage tabPage_labels;
    }
}